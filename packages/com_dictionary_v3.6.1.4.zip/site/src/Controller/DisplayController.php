<?php
namespace Webeau\Component\Dictionary\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

/**
 * Dictionary Component Controller
 *
 * @since  4.0.0
 */
class DisplayController extends BaseController
{
    
	/**
	 * The default view.
	 *
	 * @var    string
	 * @since  1.6
	 */
	protected $default_view = 'definitions';

	protected $app;
}