<?php

\defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Factory;
use Joomla\CMS\WebAsset\WebAssetManager;

$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));

$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
$wr = $wa->getRegistry();
$wr->addRegistryFile('media/com_dictionary/joomla.asset.json');
//$wa->useStyle('dictionary');

?>
<h1><?php echo Text::_('COM_DICTIONARY'); ?></h1>

<div class="atoz col-md-12">
    <div class="glossary-items">
    
        <div id="t3-content" class="t3-content col-xs-12">
    
            <div class="glossary-nav">
                <nav class="affix-top">
                    <ul class="nav nav-pills">
                        <!-- Loop the letters here -->
                        <?php foreach ($this->items as $id => $item) : ?>
                            <?php echo $item->word.'<br/>'; ?>
                        <?php endforeach; ?>
                    </ul>
                </nav>
            </div>
            <!--where the word definitions stay-->
        </div>
    </div>
</div>
