<?php

/**
 * @version     3.6.2
 * @package     com_dictionary search plugin
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net and updated by adedayo@jibitech.com
 **/

namespace Webeau\Plugin\Finder\Dictionary\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Table\Table;
use Joomla\Component\Finder\Administrator\Indexer\Adapter;
use Joomla\Component\Finder\Administrator\Indexer\Helper;
use Joomla\Component\Finder\Administrator\Indexer\Indexer;
use Joomla\Component\Finder\Administrator\Indexer\Result;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\DatabaseQuery;
use Joomla\Registry\Registry;
use Webeau\Component\Dictionary\Site\Helper\RouteHelper;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * Finder Plugin for indexing Dictionary words and definitions.
 */
final class Dictionary extends Adapter
{
	use DatabaseAwareTrait;
	/**
     * The plugin identifier.
     *
     * @var    string
     * @since  2.5
     */
    protected $context = 'Dictionary';

    /**
     * The extension name.
     *
     * @var    string
     * @since  2.5
     */
    protected $extension = 'com_dictionary';

	/**
     * The sublayout to use when rendering the results.
     *
     * @var    string
     * @since  2.5
     */
    protected $layout = 'definitions';

	/**
     * The type of content that the adapter indexes.
     *
     * @var    string
     * @since  2.5
     */
    protected $type_title = 'Dictionary';

    /**
     * The table name.
     *
     * @var    string
     * @since  2.5
     */
    protected $table = '#__dictionary_letter_def';

	 /**
     * The field the published state is stored in.
     *
     * @var    string
     * @since  2.5
     */
    protected $state_field = 'published';

    /**
     * Load the language file on instantiation.
     *
     * @var    boolean
     * @since  3.1
     */
    protected $autoloadLanguage = true;

	 /**
     * Method to remove the link information for items that have been deleted.
     *
     * This event will fire when contacts are deleted and when an indexed item is deleted.
     *
     * @param   string  $context  The context of the action being performed.
     * @param   Table   $table    A Table object containing the record to be deleted
     *
     * @return  void
     *
     * @since   2.5
     * @throws  \Exception on database error.
     */
    public function onFinderAfterDelete($context, $table): void
    {
        if ($context === 'com_dictionary.word') {
            $id = $table->id;
        } elseif ($context === 'com_finder.index') {
            $id = $table->link_id;
        } else {
            return;
        }

        // Remove the items.
        $this->remove($id);
    }

	 /**
     * Method to determine if the access level of an item changed.
     *
     * @param   string   $context  The context of the content passed to the plugin.
     * @param   Table    $row      A Table object
     * @param   boolean  $isNew    If the content has just been created
     *
     * @return  void
     *
     * @since   3.1
     * @throws  \Exception on database error.
     */
    public function onFinderAfterSave($context, $row, $isNew): void
    {
        // We only want to handle the dictionary words here.
        if ($context === 'com_dictionary.word') {
            // Check if the access levels are different
            if (!$isNew && $this->old_access != $row->access) {
                // Process the change.
                $this->itemAccessChange($row);
            }

            // Reindex the item
            $this->reindex($row->id);
        }
    }

	/**
     * Method to reindex the link information for an item that has been saved.
     * This event is fired before the data is actually saved so we are going
     * to queue the item to be indexed later.
     *
     * @param   string   $context  The context of the content passed to the plugin.
     * @param   Table    $row      A Table object
     * @param   boolean  $isNew    If the content is just about to be created
     *
     * @return  boolean  True on success.
     *
     * @since   3.1
     * @throws  \Exception on database error.
     */
    public function onFinderBeforeSave($context, $row, $isNew)
    {
        // We only want to handle the dictionary words here
        if ($context === 'com_dictionary.word') {
            // Query the database for the old access level if the item isn't new
            if (!$isNew) {
                $this->checkItemAccess($row);
            }
        }

        return true;
    }

	 /**
     * Method to update the link information for items that have been changed
     * from outside the edit screen. This is fired when the item is published,
     * unpublished, archived, or unarchived from the list view.
     *
     * @param   string   $context  The context for the content passed to the plugin.
     * @param   array    $pks      A list of primary key ids of the content that has changed state.
     * @param   integer  $value    The value of the state that the content has been changed to.
     *
     * @return  void
     *
     * @since   3.1
     */
    public function onFinderChangeState($context, $pks, $value)
    {
        // We only want to handle the dictionary words here
        if ($context === 'com_dictionary.word') {
            $this->itemStateChange($pks, $value);
        }

        // Handle when the plugin is disabled
        if ($context === 'com_plugins.plugin' && $value === 0) {
            $this->pluginDisable($pks);
        }
    }

	
    /**
     * Method to get the SQL query used to retrieve the list of content items.
     *
     * @param   mixed  $query  A DatabaseQuery object or null.
     *
     * @return  DatabaseQuery  A database object.
     *
     * @since   3.1
     */
    protected function getListQuery($query = null)
	{
		$db = $this->getDatabase();

        // Check if we can use the supplied SQL query.
        $query = $query instanceof DatabaseQuery ? $query : $db->getQuery(true)
			->select(['a.id', 'a.word AS title', 'a.definition AS body', 'a.published AS state', 'a.access', 'a.created AS start_date'])
			->from('#__dictionary_letter_def AS a');
		return $query;
	}

	/**
     * Method to index an item. The item must be a Result object.
     *
     * @param   Result  $item  The item to index as a Result object.
     *
     * @return  void
     *
     * @since   2.5
     * @throws  \Exception on database error.
     */
    protected function index(Result $item)
	{
		// Check if the extension is enabled
        if (ComponentHelper::isEnabled($this->extension) === false) {
            return;
        }

        $item->setLanguage();

		// Initialize the item parameters.
        $registry     = new Registry($item->params);
        $item->params = clone ComponentHelper::getParams('com_dictionary', true);
        $item->params->merge($registry);
		
		$item->metadata = new Registry($item->metadata);
		// Create a URL as identifier to recognise items again.
        $item->url = $this->getUrl($item->id, $this->extension, $this->layout);
		
        // Build the necessary route and path information.
        $item->route = RouteHelper::getDictionaryRoute($item->id, $item->language);
		
        // Get the menu title if it exists.
        $title = $this->getItemMenuTitle($item->url);

        // Adjust the title if necessary.
        if (!empty($title) && $this->params->get('use_menu_title', true)) {
            $item->title = $title;
        }
		// Trigger the onContentPrepare event.
        $item->summary = Helper::prepareContent($item->body, $item->params, $item);
        $item->body    = Helper::prepareContent($item->body, $item->params, $item);


        // Handle the link to the metadata.
        //$item->addInstruction(Indexer::META_CONTEXT, 'link');
        $item->addInstruction(Indexer::META_CONTEXT, 'metakey');
        $item->addInstruction(Indexer::META_CONTEXT, 'metadesc');
        $item->addInstruction(Indexer::META_CONTEXT, 'metaauthor');
        $item->addInstruction(Indexer::META_CONTEXT, 'author');
        $item->addInstruction(Indexer::META_CONTEXT, 'created_by_alias');

        // Get taxonomies to display
        $taxonomies = $this->params->get('taxonomies', ['type', 'author', 'language']);

        // Add the type taxonomy data.
        if (\in_array('type', $taxonomies)) {
            $item->addTaxonomy('Type', 'Dictionary');
        }

        // Add the author taxonomy data.
        if (\in_array('author', $taxonomies) && (!empty($item->author) || !empty($item->created_by_alias))) {
            $item->addTaxonomy('Author', !empty($item->created_by_alias) ? $item->created_by_alias : $item->author);
        }

        // Add the language taxonomy data.
        if (\in_array('language', $taxonomies)) {
            $item->addTaxonomy('Language', $item->language);
        }

		// Get content extras.
		Helper::getContentExtras($item);
		Helper::addCustomFields($item, $this->context);

		// Index the item.
		$this->indexer->index($item);


	}

	/**
     * Method to setup the indexer to be run.
     *
     * @return  boolean  True on success.
     *
     * @since   3.1
     */
    protected function setup()
    {
        return true;
    }
}
