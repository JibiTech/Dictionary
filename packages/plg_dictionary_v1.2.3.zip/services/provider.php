<?php

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Event\DispatcherInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\Language\Language;
use Joomla\Database\DatabaseInterface;

use Webeau\Plugin\Finder\Dictionary\Extension\Dictionary;

    return new class() implements ServiceProviderInterface
    {
        public function register(Container $container)
        {
           /* $container->set(
                PluginInterface::class,
                function (Container $container) {
    
                    $config = (array) PluginHelper::getPlugin('search', 'dictionary');
                    $subject = $container->get(DispatcherInterface::class);
                    $app = Factory::getApplication();

                    $container = Factory::getContainer();
                    
                    $plugin = new Dictionary($subject, $config, $app, $container->get('DatabaseDriver'),Factory::getApplication()->getIdentity());
                    $plugin->setApplication($app);
    
                    return $plugin;
                }
            ); */

            $container->set(
                PluginInterface::class,
                function (Container $container) {
                    $plugin     = new Dictionary(
                        $container->get(DispatcherInterface::class),
                        (array) PluginHelper::getPlugin('finder', 'dictionary')
                    );
                    $plugin->setApplication(Factory::getApplication());
                    $plugin->setDatabase($container->get(DatabaseInterface::class));
    
                    return $plugin;
                }
            );
        }
    };