<?php

namespace Webeau\Component\Dictionary\Administrator\Controller;
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

/**
 * Controller for a single record
 *
 * @since  1.6
 */
class LetterController extends FormController
{
}
