<?php
namespace Webeau\Component\Dictionary\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Database\ParameterType;

/**
 * Methods to list Dictionary records.
 *
 * @since  1.6
 */
class DefinitionsModel extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see     \JController
	 * @since   1.6
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id',
				'a.id',
				'letter_id',
				'a.letter_id', 'word','a.word','definition','a.definition',
                'published', 'a.published',
				'state',
				'a.state',
				'checked_out',
				'a.checked_out', 'checked_out_time',
				'a.checked_out_time',
				'created',
				'a.created',
				'access',
				'a.access', 'hits', 'a.hits', 'ordering','a.ordering', 'language', 'a.language',
			);
		}

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * This method should only be called once per instantiation and is designed
	 * to be called on the first call to the getState() method unless the model
	 * configuration flag to ignore the request is set.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   An optional ordering field.
	 * @param   string  $direction  An optional direction (asc|desc).
	 *
	 * @return  void
	 *
	 * @since   3.0.1
	 */
	protected function populateState($ordering = 'word', $direction = 'ASC')
	{
		// List state information.
		parent::populateState($ordering, $direction);
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string  A store id.
	 *
	 * @since   1.6
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.published');

		return parent::getStoreId($id);
	}

	/**
	 * Get the master query for retrieving a list of countries subject to the model state.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 *
	 * @since   1.6
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db = $this->getDatabase();
		$query = $db->getQuery(true);

		// Select the required fields from the table. $sql = "SELECT a.id, a.letter_id, a.word, a.definition, a.published, a.state, a.checked_out, a.checked_out_time, a.created, a.access, a.hits, a.ordering, a.language, b.id, b.letter_name FROM `o5ana_dictionary_letter_def` as a LEFT JOIN `o5ana_dictionary_letters`as b ON a.letter_id = b.id;";
		$query->select(
			$this->getState(
				'list.select',
				[
					$db->quoteName('a.letter_id'),
					$db->quoteName('a.word'),
					$db->quoteName('a.definition'),
					$db->quoteName('a.published'),
					$db->quoteName('a.state'),
					$db->quoteName('a.checked_out'),
					$db->quoteName('a.checked_out_time'),
					$db->quoteName('a.created'),
					$db->quoteName('a.access'),
                    $db->quoteName('a.hits'),
                    $db->quoteName('a.ordering'),
                    $db->quoteName('a.language'),
					$db->quoteName('b.id'),
					$db->quoteName('b.letter_name'),
				]
			)
		)
			->from($db->quoteName('#__dictionary_letter_def', 'a'))
			->join('LEFT', $db->quoteName('#__dictionary_letters', 'b') . 'ON a.letter_id = b.id');

		// Filter by search in title.
		$search = $this->getState('filter.search');

		if (!empty($search)) {
			$search = $db->quote('%' . str_replace(' ', '%', $db->escape(trim($search), true) . '%'));
			$query->where('(a.word LIKE ' . $search . ')');
		}

		// Filter by published state
		$published = (string) $this->getState('filter.published');

		if ($published !== '*') {
			if (is_numeric($published)) {
				$state = (int) $published;
				$query->where($db->quoteName('a.state') . ' = :state')
					->bind(':state', $state, ParameterType::INTEGER);
			}
		}

		// Add the list ordering clause.
		$orderCol = $this->state->get('list.ordering', 'a.title');
		$orderDirn = $this->state->get('list.direction', 'ASC');

		$query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));
		return $query;
	}

}