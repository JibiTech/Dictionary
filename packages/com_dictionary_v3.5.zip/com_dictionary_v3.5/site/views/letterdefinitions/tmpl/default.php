<?php
/**
 * @version     2.0.0
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net
 **/
 
// no direct access

defined('_JEXEC') or die;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Router\Route;
$doc = JFactory::getDocument();

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');

$user = JFactory::getUser();
$userId = $user->get('id');

$doc->addStyleSheet(JURI::base() . 'components/com_dictionary/assets/css/dictionnary.css');
$langd =JFactory::getLanguage()->getTag();
  $lang = '';
 if (Multilanguage::isEnabled())
                {
 $lang = !is_null($langd) && $langd != "*" ? " AND (language='" . JFactory::getLanguage()->getTag()."' OR language='*')" : "'*'";
                }
?>
<meta name="viewport" content="width=device-width" />
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<?php

$def =  $_POST['def'];

$db = JFactory::getDbo();
$q1 = $db->getQuery(true);
$q2 = $db->getQuery(true);

	
$q1 = "SELECT * FROM #__dictionary_letters WHERE state = '1' ORDER BY letter_name";	
$db->setQuery($q1);
$r1 = $db->loadObjectList();
$c = ceil(count($r1)/3);

$counter = 1;
?>

<?php 

 $app = JFactory::getApplication()->getParams();
 $tview = $app->get('show_template');
 //echo $tview;
if($tview == '0') {

 ?>
 <style type="text/css"> .collapse.in{display:block;}</style>
<div class="atoz col-md-12">
<?php
	echo "<div class='lexique'>";
	for($i=0; $i<count($r1); $i++)
	{
		echo "<div class='set'><h3 class='letter'>". $r1[$i]->letter_name ."</h3>";

		 $q2 = "SELECT * FROM `#__dictionary_letter_def` WHERE letter_id='". $r1[$i]->id ."'  ".$lang." ORDER BY word";
     //   die();
		$db->setQuery($q2);
		$r2 = $db->loadObjectList();

		echo '<ul>';
		for($j=0; $j<count($r2); $j++)
		{
			echo "<div id='counter-".$counter."' class='spoiler'><a data-toggle='collapse' data-target='#toggle-example-".$counter."'>". $r2[$j]->word ."</a><div id='toggle-example-".$counter."' class='collapse'>". $r2[$j]->definition ."</div></div>";
			$counter++;
		}
		echo "</ul></div>";
	}
	echo "</div>";
	
?>
</div>
<style>
.atoz.col-md-12 {
    background: #fff;
    padding: 20px;
}	
 </style>
<?php } else { ?>



<?php
$def =  $_POST['def'];


$db = JFactory::getDbo();
$q1 = $db->getQuery(true);
$q2 = $db->getQuery(true);

$q1 = "SELECT * FROM #__dictionary_letters WHERE state = '1'  ORDER BY letter_name";	
$db->setQuery($q1);
$r1 = $db->loadObjectList();
$c = ceil(count($r1)/3);

$counter = 1;
?>
<style type="text/css">
	.atoz.col-md-12 {
    background: #fff;
    padding: 20px;
    width:  1024px;
    max-width: 100%;
    margin: auto;
}
.atoz .nav-pills {
    margin-left: 0!important;
}
.atoz .glossary-nav nav {
    padding: 0 48px 0 0;
    -webkit-transition: top 500ms ease 0s;
    -o-transition: top 500ms ease 0s;
    transition: top 500ms ease 0s;
}
.atoz .glossary-nav nav .nav-pills {
    background: #67707c;
}
.atoz .glossary-nav nav .nav-pills > li {
    border-right: 1px solid #ffffff;
    margin: 0;
}
.nav-pills>li {
    float: left;
}
.atoz .glossary-nav nav .nav-pills > li > a {
    padding: 8px 10px!important;
    font-size: 24px;
    line-height: normal;
    background: #67707c;
    color: #fff !important;
    font-weight: 600 !important;
    text-transform: uppercase;
    font-size: 15px;
}
.atoz .glossary-group-title {
    margin: 0 0 24px;
    font-weight: 600;
    font-size: 35px;
    background: #f6f8f8;
    color: #344150;
    padding: 10px 15px;
    text-transform: uppercase;
}
.atoz .glossary-group-items ul > li > a {
    color: #67707c !important;
    font-size: 18px;
    cursor: pointer;
}
.fade.in {
    opacity: 1;
}
.modal {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 1050;
    display: none;
    overflow: hidden;
    -webkit-overflow-scrolling: touch;
    outline: 0;
}
.modal-open .modal {
    overflow-x: hidden;
    overflow-y: auto;
}
.modal.in .modal-dialog {
    -webkit-transform: translate(0,0);
    -ms-transform: translate(0,0);
    -o-transform: translate(0,0);
    transform: translate(0,0);
}


.modal-dialog {
    position: relative;
    width: auto;
    margin: 10px;
}
.modal-content {
    -webkit-box-shadow: 0 5px 15px rgba(0,0,0,.5);
    box-shadow: 0 5px 15px rgba(0,0,0,.5);
}

.modal-content {
    position: relative;
    background-color: #fff;
    -webkit-background-clip: padding-box;
    background-clip: padding-box;
    border: 1px solid #999;
    border: 1px solid rgba(0,0,0,.2);
    border-radius: 6px;
    outline: 0;
    -webkit-box-shadow: 0 3px 9px rgba(0,0,0,.5);
    box-shadow: 0 3px 9px rgba(0,0,0,.5);
}
.dmodel .modal-header {
    padding: 15px;
    border-bottom: 1px solid #e5e5e5;
    display: block;
}
.modal-body {
    position: relative;
    padding: 15px;
}
.modal-backdrop.in {
    filter: alpha(opacity=50);
    opacity: .5;
}
.dmodel  .modal-dialog {
    position: relative;
    width: auto;
  margin: 50px auto;
}
.close {
    float: right;
    font-size: 21px;
    font-weight: 700;
    line-height: 1;
    color: #000;
    text-shadow: 0 1px 0 #fff;
    filter: alpha(opacity=20);
    opacity: .2;
}
</style>
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->


<div class="atoz col-md-12">
<div class="glossary-items">
	
<div id="t3-content" class="t3-content col-xs-12">

	<div class="glossary-nav">
		<nav class="affix-top">
			<ul class="nav nav-pills">
			<?php for($i=0; $i<count($r1); $i++) { ?>
			<li><a href="#<?php echo strtolower($r1[$i]->letter_name); ?>"><?php echo $r1[$i]->letter_name; ?></a></li>
			<?php } ?>											
		</nav>
	</div>
	<div class="glossary-items">
		<div class="glossary-group">		
			<?php for($i=0; $i<count($r1); $i++) { ?>
			<a name="<?php echo strtolower($r1[$i]->letter_name); ?>"></a>
			<h3 class="glossary-group-title"><?php echo $r1[$i]->letter_name; ?></h3>
			
			<div class="glossary-group-items">
			<ul class="row">
	

<?php
$q2 = "SELECT * FROM `#__dictionary_letter_def` WHERE state = '1' and letter_id='". $r1[$i]->id ."'  ".$lang." ORDER BY word" ;
$db->setQuery($q2);
$r2 = $db->loadObjectList();
for($j=0; $j<count($r2); $j++)
{
$string = preg_replace('/\s+/', '', $r2[$j]->word);
?>


       
		<li class="col-xs-12 col-sm-6 col-md-3">		
		<a type="button" class="" data-toggle="modal" data-target="#myModal<?php echo $string; ?>"><?php echo $r2[$j]->word; ?></a>
		<!-- Modal -->
		<div id="myModal<?php echo $string; ?>" class="dmodel modal fade " role="dialog">
		  <div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content" >
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title"><?php echo $r2[$j]->word; ?></h4>
			  </div>
			  <div class="modal-body">
				<?php echo $r2[$j]->definition ; ?>
			  </div>
			</div>
		  </div>
		</div>				      
		</li>	

<?php
}
?>
			</ul>
			</div>
			<?php } ?>	
		</div>
	</div>

</div>
</div>



</div>


 <style>
.atoz .glossary-group-title {
    margin: 0 0 24px;
    font-weight: 600;
    font-size: 44px;
    background: #f6f8f8;
    color: #344150;
    padding: 10px 15px;
    text-transform: uppercase;
}
.atoz .glossary-group-items ul > li > a {
    color: #67707c;
    font-size: 18px;
	cursor: pointer;
}
.atoz .glossary-group-items ul > li {
    list-style: none;
    padding: 5px 15px;
	WIDTH: 29%;
    float: left;
}

.atoz .glossary-nav nav {
    padding: 0 48px 0 0;
    -webkit-transition: top 500ms ease 0s;
    -o-transition: top 500ms ease 0s;
    transition: top 500ms ease 0s;
}
.atoz .glossary-nav nav .nav-pills {
    background: #67707c;
}
.atoz .glossary-nav nav .nav-pills > li {
    border-right: 1px solid #ffffff;
    margin: 0;
}
.atoz .glossary-nav nav .nav-pills > li > a {
    padding: 8px 10px
    font-size: 24px;
    line-height: normal;
    background: #67707c;
    color: #fff;
    font-weight: 600;
    text-transform: uppercase;
	font-size:15px;
}
.modal-body {font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    font-size: 14px;
    line-height: 1.42857143;
    color: #333; }
.atoz.col-md-12 {
    background: #fff;
    padding: 20px;
}	
 </style>
<?php } ?>