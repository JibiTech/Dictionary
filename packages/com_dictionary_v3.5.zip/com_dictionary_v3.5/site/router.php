<?php

/**
 * @version     2.0.0
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net
 **/
 
// No direct access
defined('_JEXEC') or die;

/**
 * @param	array	A named array
 * @return	array
 */

use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Component\Router\RouterView;

class DictionaryRouter extends JComponentRouterView
{
    protected $noIDs = false;
    
    /**
     * Community Surveys Component router constructor
     *
     * @param   JApplicationCms  $app   The application object
     * @param   JMenu            $menu  The menu object to work with
     */
    public function __construct($app = null, $menu = null)
    {
        //$params = JComponentHelper::getParams('com_dictionary');
        //$this->noIDs = (bool) $params->get('sef_ids');
        
        $letterdefinitions = new RouterViewConfiguration('letterdefinitions');

           $this->registerView($letterdefinitions);
        
             parent::__construct($app, $menu);
        
             $this->attachRule(new MenuRules($this));
            $this->attachRule(new StandardRules($this));
            $this->attachRule(new NomenuRules($this));
       
    }
}
function DictionaryBuildRoute(&$query) {
    $segments = array();

       // $letterdefinitions = new RouterViewConfiguration('letterdefinitions');
        $RouterView = new DictionaryRouter();
    //$RouterView->registerView($letterdefinitions);

    if (isset($query['task'])) {
        $segments[] = implode('/', explode('.', $query['task']));
        unset($query['task']);
    }
    if (isset($query['view'])) {
        $segments[] = $query['view'];
        unset($query['view']);
    }
    if (isset($query['id'])) {
        $segments[] = $query['id'];
        unset($query['id']);
    }

    return $segments;
}

/**
 * @param	array	A named array
 * @param	array
 *
 * Formats:
 *
 * index.php?/dictionary/task/id/Itemid
 *
 * index.php?/dictionary/id/Itemid
 */
function DictionaryParseRoute($segments) {
    $vars = array();

    // view is always the first element of the array
    $vars['view'] = array_shift($segments);

    while (!empty($segments)) {
        $segment = array_pop($segments);
        if (is_numeric($segment)) {
            $vars['id'] = $segment;
        } else {
            $vars['task'] = $vars['view'] . '.' . $segment;
        }
    }

    return $vars;
}

