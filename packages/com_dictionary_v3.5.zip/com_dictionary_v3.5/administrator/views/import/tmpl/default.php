<?php
/**
 * @version     2.0.0
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net
 **/

// no direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Associations;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\Registry\Registry;

JHtml::addIncludePath(JPATH_COMPONENT.'/helpers/html');
/*
JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');*/

// Import CSS
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_dictionary/assets/css/dictionary.css');

$user	= JFactory::getUser();
$userId	= $user->get('id');

//Joomla Component Creator code to allow adding non select list filters
if (!empty($this->extra_sidebar)) {
    $this->sidebar .= $this->extra_sidebar;
}
?>
<style type="text/css">.btn-group, .btn-group-vertical {
    display: inline-flex;
    position: relative;
    vertical-align: middle;
    margin-left: 5px;
} .dcnav .sidebar-nav {
    padding: 0;
    margin: 10px 0;
    background: #fff;
}.dcnav .flex-column {
    flex-direction: row !important;
}.dcnav .sidebar-nav li {
    font-size: .9rem;
    font-weight: 700;
    display: inline-block;
    margin: 0 5px;
    padding: 5px 10px;
}</style>
<form action="<?php echo JRoute::_('index.php?option=com_dictionary&view=import'); ?>" method="post" name="adminForm"  id="adminForm" enctype="multipart/form-data">
<?php if(!empty($this->sidebar)): ?>
	<div id="j-sidebar-container" class="span2 dcnav">
		<?php echo $this->sidebar; ?>
	</div>
	<div id="j-main-container" class="span10">
<?php else : ?>
	<div id="j-main-container">
<?php endif;?>
		<div class="clearfix"> </div>
		
		
		<div class="file-field">
              <div class="btn btn-primary btn-sm float-left">
                <span>Choose file</span>
                <input type="file"  name="fileupload">
            </div>
            <div class="file-path-wrapper">
             <input type="hidden" name="task" value="import.importcsv" />
            </div>
            </div>

		<div id="filter-bar" class="btn-toolbar">

		</div>        
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>        

		
