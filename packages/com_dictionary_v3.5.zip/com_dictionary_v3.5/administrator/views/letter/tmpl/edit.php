<?php
/**
 * @version     2.0.0
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net
 **/
 
// no direct access
defined('_JEXEC') or die;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Associations;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\Registry\Registry;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
    ->useScript('form.validate');
    // ->useScript('com_dictionary.letter-edit');
/*
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');*/


// Import CSS
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_dictionary/assets/css/dictionary.css');
?>
<script type="text/javascript">
    js = jQuery.noConflict();
    js(document).ready(function() {
        
    });

    Joomla.submitbutton = function(task)
    {
        if (task == 'letter.cancel') {
            Joomla.submitform(task, document.getElementById('letter-form'));
        }
        else {
            
            if (task != 'letter.cancel' && document.formvalidator.isValid(document.getElementById('letter-form'))) {
                
                Joomla.submitform(task, document.getElementById('letter-form'));
            }
            else {
                alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
            }
        }
    }
</script>

<form action="<?php echo JRoute::_('index.php?option=com_dictionary&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="letter-form" class="form-validate">

    <div class="form-horizontal">
        <?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>

        <?php echo JHtml::_('bootstrap.addTab', 'myTab', 'general', JText::_('COM_DICTIONARY_TITLE_LETTER', true)); ?>
        <div class="row-fluid">
            <div class="span9 form-horizontal">
                <fieldset class="adminform">

                    				<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('letter_name'); ?></div>				
				<div class="controls">
				<?php echo $this->form->getInput('letter_name'); ?>
				</div>
				</br>
				<div class="control-label"><?php echo 'Date'; ?></div>				
				<div class="controls">
                <?php echo $this->form->getInput('created'); ?>
				
				</div>

			</div>
 
                </fieldset>
            </div>
			
			 <div class="span3">
				<?php echo JLayoutHelper::render('joomla.edit.global', $this); ?>
				<?php echo $this->form->getInput('rules'); ?>
			</div>
        </div>
        <?php echo JHtml::_('bootstrap.endTab'); ?>
        
        

        <?php echo JHtml::_('bootstrap.endTabSet'); ?>

        <input type="hidden" name="task" value="" />
        <?php echo JHtml::_('form.token'); ?>

    </div>
</form>
