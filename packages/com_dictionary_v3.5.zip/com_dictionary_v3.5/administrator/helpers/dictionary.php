<?php

/**
 * @version     2.0.0
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net
 **/
 
 
// No direct access
defined('_JEXEC') or die;

/**
 * Dictionary helper.
 */
class DictionaryHelper {

    /**
     * Configure the Linkbar.
     */
    public static function addSubmenu($vName = '') {
        		JHtmlSidebar::addEntry(
			JText::_('COM_DICTIONARY_TITLE_LETTERS'),
			'index.php?option=com_dictionary&view=letters',
			$vName == 'letters');
		
		JHtmlSidebar::addEntry(
		JText::_('COM_DICTIONARY_TITLE_LETTERDEFINITIONS')
		,'index.php?option=com_dictionary&view=letterdefinitions',
		$vName == 'letterdefinitions');

        JHtmlSidebar::addEntry(
        JText::_('Import')
        ,'index.php?option=com_dictionary&view=import',
        $vName == 'Import');
		
  }

    /**
     * Gets a list of the actions that can be performed.
     *
     * @return	JObject
     * @since	1.6
     */
    public static function getActions() {
        $user = JFactory::getUser();
        $result = new JObject;

        $assetName = 'com_dictionary';

        $actions = array(
            'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
        );

        foreach ($actions as $action) {
            $result->set($action, $user->authorise($action, $assetName));
        }

        return $result;
    }


}
