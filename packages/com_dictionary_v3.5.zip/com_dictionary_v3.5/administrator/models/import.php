<?php

/**
 * @version     2.0.0
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net
 **/
 
 
defined('_JEXEC') or die;

jimport('joomla.application.component.modellist');

/**
 * Methods supporting a list of Dictionary records.
 */
class DictionaryModelImport extends JModelList {

    /**
     * Constructor.
     *
     * @param    array    An optional associative array of configuration settings.
     * @see        JController
     * @since    1.6
     */
    public function __construct($config = array()) {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = array(
                                'id', 'a.id',
                'letter_name', 'a.letter_name',

            );
        }

        parent::__construct($config);
    }

    /**
     * Build an SQL query to load the list data.
     *
     * @return	JDatabaseQuery
     * @since	1.6
     */
    protected function getListQuery() {
        // Create a new query object.
        $db = $this->getDbo();
        $query = $db->getQuery(true);

        // Select the required fields from the table.
        $query->select(
                $this->getState(
                        'list.select', 'DISTINCT a.*'
                )
        );
        $query->from('`#__dictionary_letters` AS a');
        return $query;
    }

    function import($file_tmp_name, $file_name)
    {
        //echo "<pre>";
        $path = JPATH_COMPONENT_ADMINISTRATOR . "/" . $file_name;
        JFile::upload($file_tmp_name, $path);
		


        chmod($path, 0777);
        if (($handle = @fopen($path, "r")) !== FALSE) {
            $counter = 0;

            while (($data = fgetcsv($handle)) !== FALSE) {

                if($counter == 0) { $counter++ ; continue; }

               $letter[$counter] = $data[0];

                // $letter[$counter] = array(
                //     "letter_id" => $data[1],
                //     "letter_name" => $data[2]
                //     );

                $definitions[$counter] = array(
                    "letter_name" => $data[0],
                    "word" => $data[1],
                    "definition" => $data[2]
                    );

                $counter++;
            }
            fclose($handle);

            $letter = array_values(array_unique($letter));
            $letter = array_combine(range(1, count($letter)), array_values($letter));

            for ($i=1; $i <= count($letter) ; $i++) { 
                $letters[$i] = array(
                    "letter_id" => $i,
                    "letter_name" => $letter[$i]
                    );
            }

            for ($i=1; $i <= count($definitions) ; $i++)
            { 
                for ($j=1; $j <= count($letters) ; $j++)
                { 
                    if($definitions[$i]["letter_name"] == $letters[$j]["letter_name"])
                    {
                        $definitions[$i]["letter_id"] = $letters[$j]["letter_id"];
                    }
                }
            }

            $db = JFactory::getDbo();
            $insert_letters = $db->getQuery(true);
            $insert_definitions = $db->getQuery(true);

            for ($i=1; $i <= count($letters) ; $i++) { 
                $insert_letters  = "insert into #__dictionary_letters (id,letter_name) values (".addslashes($letters[$i]['letter_id']).",'".addslashes($letters[$i]['letter_name'])."')";
                $db->setQuery($insert_letters);
                $db->execute(); 
            }

            for ($i=1; $i <= count($definitions) ; $i++) { 
                if ( empty($definitions[$i]['word'])) { continue; }

                $insert_definitions  = "insert into #__dictionary_letter_def (letter_id,word,definition) values (".addslashes($definitions[$i]['letter_id']).",'".addslashes($definitions[$i]['word'])."','".addslashes($definitions[$i]['definition'])."')";
                $db->setQuery($insert_definitions);
                $db->execute(); 
            }
        }
        unlink($path);
        
    }

}
