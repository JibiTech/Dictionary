<?php
/**
 * @version     2.0.0
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net
 **/

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.controlleradmin');
use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Path;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\Input\Input;
use Joomla\Utilities\ArrayHelper;
/**
 * Letters list controller class.
 */

class DictionaryControllerImport extends BaseController
{
    public function __construct($config = [], MVCFactoryInterface $factory = null, $app = null, $input = null)
    {
        $this->app      = Factory::getApplication();
    
        if (empty($this->input))
        {
            $this->input = $this->app->input;
        }

        parent::__construct($config, $factory, $app, $input);
    }

/*
	public function getModel($name = 'Import', $prefix = 'DictionaryModel')
	{
		//$model = parent::getModel($name, $prefix, array('ignore_request' => true));
		$model  = $this->getModel($name, $prefix, array('ignore_request' => true));
		return $model;
	}*/
    
    public function export()
	{
		function generatecsv(array &$export)
		{
			if(count($export)){
				ob_start();
	   			$df = fopen("php://output", 'w');
	     	    foreach ($export as $row) {
		  		    fputcsv($df, $row);
	     		}
			   	fclose($df);
	   			return ob_get_clean();
			}
		}

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query = "SELECT a.id, a.letter_name,b.word,b.definition FROM `#__dictionary_letters` AS a, `#__dictionary_letter_def` AS b WHERE a.id = b.letter_id";
		$db->setQuery($query);
		$results = $db->loadObjectList();

		$csv_export = array();

		for ($i=0; $i < count($results) ; $i++) { 
			$csv_export[$i] = array($i,$results[$i]->id,$results[$i]->letter_name,$results[$i]->word,$results[$i]->definition);
		}

		$fields = array("Id","Letter id","Letter Name","Word","Definition");
		array_unshift($csv_export, $fields);

		$filename = "Export" . "-" . date("d-m-Y") . ".csv";

		header('Content-Encoding: UTF-8');
     	header("content-type:application/csv;charset=UTF-8");
     	header("Content-Disposition: attachment;filename={$filename}");
		echo generatecsv($csv_export);
		exit;
	}
  /* -- Start New Import method 29th july -- */
	public function importcsv()
	{
		$file_tmp_path = $_FILES['fileupload']['tmp_name'];
		$file_name = $_FILES['fileupload']['name'];
		jimport('joomla.filesystem.file');
        jimport('joomla.filesystem.folder');	

$user =& Factory::getUser();
$userId = $user->get( 'id' );
		 $path = JPATH_COMPONENT_ADMINISTRATOR . '/'. "uploads" . '/' . $file_name;
		

        File::upload($file_tmp_path, $path);
      //  die('hrer');
        chmod($path, 0777);
        if (($handle = @fopen($path, "r")) !== FALSE) {
            $counter = 0;
$db = JFactory::getDbo();
            while (($data = fgetcsv($handle)) !== FALSE) {

                if($counter == 0) { $counter++ ; continue; }

               $letter[$counter] = $data[0];

$cdate = date("Y-m-d H:i:s");
               // Get a db connection.

            	
            	$querya = $db->getQuery(true);
$querya = 'SELECT id FROM #__dictionary_letters WHERE letter_name = ' . $db->quote(addslashes($data[0]));
$db->setQuery($querya, 0, 1);
$check = $db->loadResult();

if($check){
	  $lastinsertid = $check;

}else{
		$insert_definitions = $db->getQuery(true);

          //  $cdate = date("Y-m-d");

                $insert_definitions  = "insert into #__dictionary_letters (letter_name,published,state,checked_out,checked_out_time,created,access,hits,ordering) values ('".addslashes($data[0])."','1','1','".$userId."','0000-00-00 00:00:00','".$cdate."','1','1','0');";

            
                $db->setQuery($insert_definitions);
                $db->execute(); 
                $lastinsertid = $db->insertid();
}




// Create a new query object.
$query = $db->getQuery(true);

// Insert columns.
$columns = array('letter_id', 'word', 'definition', 'published', 'state', 'checked_out', 'checked_out_time', 'created', 'access', 'hits', 'ordering');

// Insert values.
$values = array($db->quote($lastinsertid),$db->quote(addslashes($data[1])),$db->quote(addslashes($data[2])),$db->quote('1'),$db->quote('1'),$db->quote($userId),$db->quote($cdate),$db->quote('0000-00-00 00:00:00'),$db->quote('0'),$db->quote('0'),$db->quote('0'));

// Prepare the insert query.
$query
    ->insert($db->quoteName('#__dictionary_letter_def'))
    ->columns($db->quoteName($columns))
    ->values(implode(',', $values));
//echo($query->__toString()); die();
// Set the query using our newly populated query object and execute it.
$db->setQuery($query);
$db->execute();


/*


			   
			//$db = Factory::getDbo();
            //$insert_letters = $db->getQuery(true);
           /// $insert_definitions = $db->getQuery(true);
            	$db = JFactory::getDbo();
		$query = $db->getQuery(true);

            $cdate = date("Y-m-d");

            echo   $query  = "insert into #__dictionary_letter_def (letter_id,word,definition,published,state,checked_out,checked_out_time,created,access,hits,ordering) values (".addslashes($data[0]).",'".addslashes($data[1])."','".addslashes($data[2])."','1','1','0000-00-00 00:00:00','".$cdate."','1','0','0','0');";
                $db->setQuery($query);
                $db->execute(); */

               $definitions[$counter] = array(
                    "letter_name" => $data[0],
                    "word" => $data[1],
                    "definition" => $data[2]
                    );

                $counter++;
            }
         
            fclose($handle);
            Factory::getApplication()->enqueueMessage('File Uploaded Succesfully');
         
        }
        unlink($path);
		$this->setRedirect(JRoute::_('index.php?option=com_dictionary', false));
	
	}
	 /* -- End New Import method 29th july -- */
}