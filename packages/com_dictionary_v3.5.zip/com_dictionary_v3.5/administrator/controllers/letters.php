<?php
/**
 * @version     2.0.0
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net
 **/

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.controlleradmin');
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\Language\LanguageHelper;
use Joomla\Component\Associations\Administrator\Helper\AssociationsHelper;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Router\Route;
/**
 * Letters list controller class.
 */
class DictionaryControllerLetters extends JControllerAdmin
{
	/**
	 * Proxy for getModel.
	 * @since	1.6
	 */
	/*public function getModel($name = 'letter', $prefix = 'DictionaryModel')
	{
		$model = parent::getModel($name, $prefix, array('ignore_request' => true));
		return $model;
	}*/
    
    
	/**
	 * Method to save the submitted ordering values for records via AJAX.
	 *
	 * @return  void
	 *
	 * @since   3.0
	 */
	public function saveOrderAjax()
	{
		// Get the input
		$input = JFactory::getApplication()->input;
		$pks = $input->post->get('cid', array(), 'array');
		$order = $input->post->get('order', array(), 'array');

		// Sanitize the input
		JArrayHelper::toInteger($pks);
		JArrayHelper::toInteger($order);

		// Get the model
		$model = $this->getModel();

		// Save the ordering
		$return = $model->saveorder($pks, $order);

		if ($return)
		{
			echo "1";
		}

		// Close the application
		JFactory::getApplication()->close();
	}

	public function export()
	{
		function generatecsv(array &$export)
		{
			if(count($export)){
				ob_start();
	   			$df = fopen("php://output", 'w');
	     	    foreach ($export as $row) {
		  		    fputcsv($df, $row);
	     		}
			   	fclose($df);
	   			return ob_get_clean();
			}
		}

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query = "SELECT a.id,a.letter_name, b.word, b.definition FROM `#__dictionary_letters` as a LEFT OUTER JOIN `#__dictionary_letter_def` as b ON a.id=b.letter_id ";
		$db->setQuery($query);
		$results = $db->loadObjectList();

		$csv_export = array();

		for ($i=0; $i < count($results) ; $i++) { 
			$csv_export[$i] = array($results[$i]->letter_name,$results[$i]->word,$results[$i]->definition);
		}

		$fields = array("Letter Name","Word","Definition");
		array_unshift($csv_export, $fields);

		$filename = "Export" . "-" . date("d-m-Y") . ".csv";

		header('Content-Encoding: UTF-8');
     	header("content-type:application/csv;charset=UTF-8");
     	header("Content-Disposition: attachment;filename={$filename}");
		echo generatecsv($csv_export);
		exit;
	}

	  public function publish($pks = null, $state = 1, $userId = 0)
	{

		$redirectUrl = 'index.php?option=com_dictionary&view=letters';
		$application = JFactory::getApplication();
		
		$pks = $_POST['cid'];
	
		  ArrayHelper::toInteger($pks);
      
        $user =& Factory::getUser();
     $userId = $user->get( 'id' );
      $state = (int) $state;

      if(count($pks) >1){
$msg = JText::sprintf('COM_DICTIONARY_N_ITEMS_PUBLISHED', count($pks));
      }else{
      	$msg = JText::sprintf('COM_DICTIONARY_N_ITEMS_PUBLISHED_1', count($pks));
      }

if($_POST['task'] == 'letters.unpublish'){
 $state = '0';
     if(count($pks) >1){
$msg = JText::sprintf('COM_DICTIONARY_N_ITEMS_UNPUBLISHED', count($pks));
      }else{
      	$msg = JText::sprintf('COM_DICTIONARY_N_ITEMS_UNPUBLISHED_1', count($pks));
      }

}
        $state = (int) $state;
$k='state';
        // If there are no primary keys set check to see if the instance key is set.
        if (empty($pks)) {
            if ($this->$k) {
                $pks = array($this->$k);
            }
            // Nothing to set publishing state on, return false.
            else {
            	return	$this->setRedirect(Route::_($redirectUrl, false), JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
            	//$application->enqueueMessage(JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'), 'error');
                //echo JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED');
             
            }
        }
  // Build the WHERE clause for the primary keys.
        $where = 'id  IN (' . implode(',',$pks).')';

        // Determine if there is checkin support for the table.
        if (!property_exists($this, 'checked_out') || !property_exists($this, 'checked_out_time')) {
            $checkin = '';
        } else {
        	$checkin = '';
          //  $checkin = ' AND (checked_out = 0 OR checked_out = ' . (int) $userId . ')';
        }
$db = JFactory::getDbo();
$insert_definitions = $db->getQuery(true);
        // Update the publishing state for rows with the given primary keys.
        $insert_definitions ='UPDATE `#__dictionary_letters`' .
                ' SET  `checked_out` = ' . (int) $userId . ', `state` = ' . (int) $state .
                ' WHERE ' . $where;

      $db->setQuery($insert_definitions);
                $db->execute(); 



        // If checkin is supported and all rows were adjusted, check them in.
        if ($checkin && (count($pks) == $db->getAffectedRows())) {
            // Checkin each row.
            foreach ($pks as $pk) {
               // $this->checkin($pk);
            }
        }

        // If the JTable instance value is in the list of primary keys that were set, set the instance.
        if (in_array($this->$k, $pks)) {
            $this->state = $state;
        }

       
      

	

	$this->setRedirect(Route::_($redirectUrl, false), $msg);
		}

		 public function delete()
    {
    	

		$redirectUrl = 'index.php?option=com_dictionary&view=letters';
		$application = JFactory::getApplication();
		
		$pks = $_POST['cid'];
	
		  ArrayHelper::toInteger($pks);
      
        $user =& Factory::getUser();
     $userId = $user->get( 'id' );
      $state = (int) $state;


        $state = (int) $state;
$k='state';
        // If there are no primary keys set check to see if the instance key is set.
        if (empty($pks)) {
            if ($this->$k) {
                $pks = array($this->$k);
            }
            // Nothing to set publishing state on, return false.
            else {
            	return	$this->setRedirect(Route::_($redirectUrl, false), JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
            	//$application->enqueueMessage(JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'), 'error');
                //echo JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED');
             
            }
        }
  // Build the WHERE clause for the primary keys.
        $where = 'id  IN (' . implode(',',$pks).')';

$db = JFactory::getDbo();
$insert_definitions = $db->getQuery(true);
        // Update the publishing state for rows with the given primary keys.
        $insert_definitions ='Delete  FROM `#__dictionary_letters`' .
                             ' WHERE ' . $where;

      $db->setQuery($insert_definitions);
                $db->execute(); 



     
     
       
      if(count($pks) >1){
$msg = JText::sprintf('COM_DICTIONARY_N_ITEMS_DELETED', count($pks));
      }else{
      	$msg = JText::sprintf('COM_DICTIONARY_N_ITEMS_DELETED_1', count($pks));
      }



	$this->setRedirect(Route::_($redirectUrl, false), $msg);
		
    }

      public function checkin()
    {
        
		$redirectUrl = 'index.php?option=com_dictionary&view=letters';
		$application = JFactory::getApplication();
		
		$pks = $_POST['cid'];
	
		  ArrayHelper::toInteger($pks);
      
        $user =& Factory::getUser();
     $userId = $user->get( 'id' );
      $state = (int) $state;

      if(count($pks) >1){
$msg = JText::sprintf('COM_DICTIONARY_N_ITEMS_CHECKED_IN_1', count($pks));
      }else{
      	$msg = JText::sprintf('COM_DICTIONARY_N_ITEMS_CHECKED_IN_MORE', count($pks));
      }

 
        // If there are no primary keys set check to see if the instance key is set.
        if (empty($pks)) {
            if ($this->$k) {
                $pks = array($this->$k);
            }
            // Nothing to set publishing state on, return false.
            else {
            	return	$this->setRedirect(Route::_($redirectUrl, false), JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
            	//$application->enqueueMessage(JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'), 'error');
                //echo JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED');
             
            }
        }
  // Build the WHERE clause for the primary keys.
        $where = 'id  IN (' . implode(',',$pks).')';

        // Determine if there is checkin support for the table.
        if (!property_exists($this, 'checked_out') || !property_exists($this, 'checked_out_time')) {
            $checkin = '';
        } else {
        	$checkin = '';
          //  $checkin = ' AND (checked_out = 0 OR checked_out = ' . (int) $userId . ')';
        }
$db = JFactory::getDbo();
$insert_definitions = $db->getQuery(true);
        // Update the publishing state for rows with the given primary keys.
        $insert_definitions ='UPDATE `#__dictionary_letters`' .
                ' SET  `checked_out` = 0 ' .
                ' WHERE ' . $where;

      $db->setQuery($insert_definitions);
                $db->execute(); 



        // If checkin is supported and all rows were adjusted, check them in.
        if ($checkin && (count($pks) == $db->getAffectedRows())) {
            // Checkin each row.
            foreach ($pks as $pk) {
               // $this->checkin($pk);
            }
        }

        // If the JTable instance value is in the list of primary keys that were set, set the instance.
        if (in_array($this->$k, $pks)) {
            $this->state = $state;
        }

       
      

	

	$this->setRedirect(Route::_($redirectUrl, false), $msg);
		
    }

}