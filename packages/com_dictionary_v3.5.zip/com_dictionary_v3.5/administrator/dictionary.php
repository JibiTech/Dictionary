<?php
/**
 * @version     2.0.0
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net
 **/


// no direct access
defined('_JEXEC') or die;

// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_dictionary')) 
{
	throw new Exception(JText::_('JERROR_ALERTNOAUTHOR'));
}
$document = JFactory::getDocument();
$document->addScript('components/com_dictionary/assets/js/jquery-3.6.0.min.js');

// Include dependancies
jimport('joomla.application.component.controller');
JLoader::register('DictionaryHelper', __DIR__ . '/helpers/dictionary.php');
$controller	= JControllerLegacy::getInstance('Dictionary');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();
