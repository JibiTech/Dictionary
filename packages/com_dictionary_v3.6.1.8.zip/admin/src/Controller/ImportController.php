<?php

namespace Webeau\Component\Dictionary\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Response\JsonResponse;
use Joomla\CMS\Router\Route;
use Joomla\Input\Input;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Path;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\Database\DatabaseInterface;
use Exception;
use Joomla\CMS\User\UserFactoryInterface;
use Joomla\CMS\Session\Session;


/**
 * Import controller class.
 *
 * @since  1.6
 */
class ImportController extends AdminController
{
	//protected CMSApplication $app;
    //protected Input $input;
    protected DatabaseInterface $db;
	protected $container;
	/**
	 * Constructor.
	 *
	 * @param   array                $config   An optional associative array of configuration settings.
	 * Recognized key values include 'name', 'default_task', 'model_path', and
	 * 'view_path' (this list is not meant to be comprehensive).
	 * @param   MVCFactoryInterface  $factory  The factory.
	 * @param   CMSApplication       $app      The Application for the dispatcher
	 * @param   Input                $input    Input
	 *
	 * @since   3.0
	 */
	public function __construct($config = array(), MVCFactoryInterface $factory = null, $app = null, $input = null)
	{
		$this->app = Factory::getApplication();
        //$this->input = $input ?: $this->app->input;
		$container = Factory::getContainer();
        $this->db = $container->get('DatabaseDriver');
		
		parent::__construct($config, $factory, $this->app, $this->input);

	}

	/**
	 * Proxy for getModel.
	 *
	 * @param   string  $name    The model name. Optional.
	 * @param   string  $prefix  The class prefix. Optional.
	 * @param   array   $config  The array of possible config values. Optional.
	 *
	 * @return  \Joomla\CMS\MVC\Model\BaseDatabaseModel
	 *
	 * @since   1.6
	 */
	public function getModel($name = 'Import', $prefix = 'Administrator', $config = array('ignore_request' => true))
	{
		return parent::getModel($name, $prefix, $config);
	}
	//derived from old code
	/**
     * Export data to a CSV file.
     */
    public function export(): void
    {
        function generateCsv(array &$export): string
        {
            if (count($export)) {
                ob_start();
                $df = fopen("php://output", 'w');
                foreach ($export as $row) {
                    fputcsv($df, $row);
                }
                fclose($df);
                return ob_get_clean();
            }

            return '';
        }

        // Query the database for data
        $query = $this->db->getQuery(true)
            ->select('a.id, a.letter_name, b.word, b.definition')
            ->from($this->db->quoteName('#__dictionary_letters', 'a'))
            ->join('INNER', $this->db->quoteName('#__dictionary_letter_def', 'b') . ' ON a.id = b.letter_id');

        $results = $this->db->setQuery($query)->loadObjectList();

        // Prepare data for CSV export
        $csv_export = [];
        foreach ($results as $i => $result) {
            $csv_export[] = [$i, $result->id, $result->letter_name, $result->word, $result->definition];
        }

        // Add headers to CSV
        $fields = ["Id", "Letter id", "Letter Name", "Word", "Definition"];
        array_unshift($csv_export, $fields);

        // Set headers for CSV download
        $filename = "Dictionary-Export-" . date("d-m-Y") . ".csv";
        header('Content-Encoding: UTF-8');
        header("Content-Type: application/csv;charset=UTF-8");
        header("Content-Disposition: attachment;filename={$filename}");
        
        // Output the CSV
        echo generateCsv($csv_export);
        exit;
    }

    /**
     * Import data from CSV.
     */
    public function importcsvold(): void
    {
        try {
            $file_tmp_path = $this->input->files->get('fileupload', null, 'tmp_name');
            $file_name = $this->input->files->get('fileupload', null, 'name');

            // Define the upload path
            $path = JPATH_COMPONENT_ADMINISTRATOR . '/uploads/' . $file_name;

            // Upload the file
            File::upload($file_tmp_path, $path);
            chmod($path, 0777);

            if (($handle = fopen($path, "r")) !== false) {
                $counter = 0;

                while (($data = fgetcsv($handle)) !== false) {
                    if ($counter === 0) {
                        $counter++;
                        continue;
                    }

                    $letter_name = $data[0];
                    $word = $data[1];
                    $definition = $data[2];
                    $userId = Factory::getUser()->id;
                    $cdate = date("Y-m-d H:i:s");

                    // Check if the letter already exists
                    $query = $this->db->getQuery(true)
                        ->select('id')
                        ->from($this->db->quoteName('#__dictionary_letters'))
                        ->where($this->db->quoteName('letter_name') . ' = ' . $this->db->quote($letter_name));

                    $letterId = $this->db->setQuery($query, 0, 1)->loadResult();

                    // Insert new letter if not found
                    if (!$letterId) {
                        $insert_query = $this->db->getQuery(true)
                            ->insert($this->db->quoteName('#__dictionary_letters'))
                            ->columns($this->db->quoteName(['letter_name', 'published', 'state', 'checked_out', 'checked_out_time', 'created', 'access', 'hits', 'ordering']))
                            ->values(implode(',', [
                                $this->db->quote($letter_name),
                                1, 1,
                                $this->db->quote($userId),
                                $this->db->quote('0000-00-00 00:00:00'),
                                $this->db->quote($cdate),
                                1, 0, 0
                            ]));
                        $this->db->setQuery($insert_query)->execute();
                        $letterId = $this->db->insertid();
                    }

                    // Insert the definition for the letter
                    $insert_definitions = $this->db->getQuery(true)
                        ->insert($this->db->quoteName('#__dictionary_letter_def'))
                        ->columns($this->db->quoteName(['letter_id', 'word', 'definition', 'published', 'state', 'checked_out', 'checked_out_time', 'created', 'access', 'hits', 'ordering']))
                        ->values(implode(',', [
                            $this->db->quote($letterId),
                            $this->db->quote($word),
                            $this->db->quote($definition),
                            1, 1,
                            $this->db->quote($userId),
                            $this->db->quote($cdate),
                            $this->db->quote('0000-00-00 00:00:00'),
                            1, 0, 0
                        ]));

                    $this->db->setQuery($insert_definitions)->execute();

                    $counter++;
                }

                fclose($handle);
                Factory::getApplication()->enqueueMessage('File uploaded successfully.');
            }

            unlink($path);
            $this->setRedirect(Route::_('index.php?option=com_dictionary', false));
        } catch (Exception $e) {
            Factory::getApplication()->enqueueMessage(Text::_('JERROR_AN_ERROR_HAS_OCCURRED'), 'error');
        }
    }

    public function importcsv(): void
    {
        try {
            // Get the uploaded file info
            $file = $this->input->files->get('fileupload');

            // Validate file upload
            if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
                throw new Exception(Text::_('JERROR_UPLOAD_FAILED'));
            }
            
            $fileName = $file['name'];
            $uploadPath = JPATH_COMPONENT_ADMINISTRATOR . '/uploads/' . $fileName;

            // Move the file to the desired location
            if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
                throw new Exception(Text::_('JERROR_UPLOAD_FAILED_MOVE'));
            }

            // Set file permissions
            chmod($uploadPath, 0777);

            // Open and process the CSV file
            if (($handle = fopen($uploadPath, "r")) !== false) {
                $counter = 0;

                while (($data = fgetcsv($handle)) !== false) {
                    if ($counter === 0) {
                        $counter++;
                        continue;
                    }

                    $letter_name = $data[0];
                    $word = $data[1];
                    $definition = $data[2];
                    $userId = Factory::getUser()->id;
                    $cdate = date("Y-m-d H:i:s");

                    // Check if the letter exists
                    $query = $this->db->getQuery(true)
                        ->select('id')
                        ->from($this->db->quoteName('#__dictionary_letters'))
                        ->where($this->db->quoteName('letter_name') . ' = ' . $this->db->quote($letter_name));

                    $letterId = $this->db->setQuery($query)->loadResult();

                    // Insert the letter if not found
                    if (!$letterId) {
                        $insert_query = $this->db->getQuery(true)
                            ->insert($this->db->quoteName('#__dictionary_letters'))
                            ->columns($this->db->quoteName([
                                'letter_name', 'published', 'state', 
                                'checked_out', 'checked_out_time', 
                                'created', 'access', 'hits', 'ordering'
                            ]))
                            ->values(implode(',', [
                                $this->db->quote($letter_name),
                                1, 1,
                                $this->db->quote($userId),
                                $this->db->quote('0000-00-00 00:00:00'),
                                $this->db->quote($cdate),
                                1, 0, 0
                            ]));
                        $this->db->setQuery($insert_query)->execute();
                        $letterId = $this->db->insertid();
                    }

                    // Insert the definition
                    $insert_definitions = $this->db->getQuery(true)
                        ->insert($this->db->quoteName('#__dictionary_letter_def'))
                        ->columns($this->db->quoteName([
                            'letter_id', 'word', 'definition', 
                            'published', 'state', 'checked_out', 
                            'checked_out_time', 'created', 'access', 
                            'hits', 'ordering'
                        ]))
                        ->values(implode(',', [
                            $this->db->quote($letterId),
                            $this->db->quote($word),
                            $this->db->quote($definition),
                            1, 1,
                            /*$this->db->quote($userId)*/0,
                            $this->db->quote($cdate),
                            $this->db->quote($cdate),
                            1, 0, 0
                        ]));

                    $this->db->setQuery($insert_definitions)->execute();

                    $counter++;
                }

                fclose($handle);
                Factory::getApplication()->enqueueMessage(Text::_('COM_DICTIONARY_UPLOAD_SUCCESS'));
            }

            // Delete the uploaded file
            unlink($uploadPath);

            $this->setRedirect(Route::_('index.php?option=com_dictionary', false));
        } catch (Exception $e) {
            Factory::getApplication()->enqueueMessage(Text::_('JERROR_AN_ERROR_HAS_OCCURRED') . ': ' . $e->getMessage(), 'error');
        }
    }
}
