<?php

namespace Webeau\Component\Dictionary\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
//use Joomla\CMS\Filesystem\File;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Database\DatabaseQueryInterface;
use RuntimeException;
use Joomla\Filesystem\File;

/**
 * Methods supporting the Dictionary import function.
 */
class ImportModel extends ListModel
{
    /**
     * Constructor.
     *
     * @param array $config An optional associative array of configuration settings.
     */
    public function __construct($config = [])
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = [
                'id', 'a.id',
                'letter_name', 'a.letter_name',
            ];
        }

        parent::__construct($config);
    }

    /**
     * Build an SQL query to load the list data.
     *
     * @return DatabaseQueryInterface
     */
    protected function getListQuery()
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true);

        // Select required fields from the table.
        $query->select($this->getState('list.select', 'DISTINCT a.*'))
              ->from($db->quoteName('#__dictionary_letters', 'a'));

        return $query;
    }
    
    /**
     * Import CSV data into the dictionary tables.
     *
     * @param string $fileTmpName Temporary file name.
     * @param string $fileName    Original file name.
     * @throws RuntimeException If an error occurs during file upload or database operations.
     */
    public function import(string $fileTmpName, string $fileName): void
    {
        $path = JPATH_COMPONENT_ADMINISTRATOR . '/' . $fileName;

        if (!File::upload($fileTmpName, $path)) {
            throw new RuntimeException('File upload failed.');
        }

        //File::chmod($path, 0777);

        // Check if the file exists first to avoid errors
        if (!file_exists($path)) {
            //Factory::getApplication()->enqueueMessage('Error: File does not exist!', 'error');
            //return;
            throw new RuntimeException('File does not exist.');
        }

        // Attempt to change file permissions
        if (chmod($path, 0777)) {
            //Factory::getApplication()->enqueueMessage('Permissions changed successfully!', 'message');
                   
            if (($handle = fopen($path, 'r')) !== false) {
                $counter = 0;
                $letters = [];
                $definitions = [];
                $letterNames = [];

                while (($data = fgetcsv($handle)) !== false) {
                    if ($counter++ == 0) {
                        continue; // Skip header row
                    }

                    $letterName = trim($data[0]);
                    $word = trim($data[1]);
                    $definition = trim($data[2]);

                    $letterNames[] = $letterName;
                    $definitions[] = [
                        'letter_name' => $letterName,
                        'word' => $word,
                        'definition' => $definition,
                    ];
                }

                fclose($handle);
                $letterNames = array_values(array_unique($letterNames));

                foreach ($letterNames as $id => $name) {
                    $letters[$id + 1] = [
                        'letter_id' => $id + 1,
                        'letter_name' => $name,
                    ];
                }

                foreach ($definitions as &$definition) {
                    foreach ($letters as $letter) {
                        if ($definition['letter_name'] === $letter['letter_name']) {
                            $definition['letter_id'] = $letter['letter_id'];
                            break;
                        }
                    }
                }
                unset($definition);

                $db = Factory::getContainer()->get('DatabaseDriver');

                foreach ($letters as $letter) {
                    $query = $db->getQuery(true)
                        ->insert($db->quoteName('#__dictionary_letters'))
                        ->columns(['id', 'letter_name'])
                        ->values($db->quote($letter['letter_id']) . ', ' . $db->quote($letter['letter_name']));
                    $db->setQuery($query)->execute();
                }

                foreach ($definitions as $definition) {
                    if (!empty($definition['word'])) {
                        $query = $db->getQuery(true)
                            ->insert($db->quoteName('#__dictionary_letter_def'))
                            ->columns(['letter_id', 'word', 'definition'])
                            ->values(
                                $db->quote($definition['letter_id']) . ', ' .
                                $db->quote($definition['word']) . ', ' .
                                $db->quote($definition['definition'])
                            );
                        $db->setQuery($query)->execute();
                    }
                }
            }

            File::delete($path);
        } else {
            // Send out an error message to the user if it fails
            //Factory::getApplication()->enqueueMessage('Failed to change file permissions.', 'error');
            throw new RuntimeException('Failed to change the file permissions. Please check your server and try again.');
        }

    }
}