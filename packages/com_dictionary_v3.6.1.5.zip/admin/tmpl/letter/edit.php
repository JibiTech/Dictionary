<?php
   \defined('_JEXEC') or die;

   use Joomla\CMS\HTML\HTMLHelper;
   use Joomla\CMS\Language\Text;
   use Joomla\CMS\Layout\LayoutHelper;
   use Joomla\CMS\Router\Route;

   use Joomla\CMS\Factory;

   HTMLHelper::_('behavior.formvalidator');
   HTMLHelper::_('behavior.keepalive');

   $wa = $this->document->getWebAssetManager();
   $wa->useStyle('dictionary_css');
   ?>
    <script type="text/javascript">
        js = jQuery.noConflict();
        js(document).ready(function() {
            
        });

        Joomla.submitbutton = function(task)
        {
            if (task == 'letter.cancel') {
                Joomla.submitform(task, document.getElementById('letter-form'));
            }
            else {
                
                if (task != 'letter.cancel' && document.formvalidator.isValid(document.getElementById('letter-form'))) {
                    
                    Joomla.submitform(task, document.getElementById('letter-form'));
                }
                else {
                    alert('<?php echo $this->escape(Text::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
                }
            }
        }
    </script>
    <form action="<?php echo Route::_('index.php?option=com_dictionary&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="letter-form" class="form-validate">

        <div class="form-horizontal">
            <?php echo HtmlHelper::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>

            <?php echo HtmlHelper::_('bootstrap.addTab', 'myTab', 'general', Text::_('COM_DICTIONARY_TITLE_LETTER', true)); ?>
            <div class="row-fluid">
                <div class="span9 form-horizontal">
                    <fieldset class="adminform">

                                        <input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
                <div class="control-group">
                    <div class="control-label"><?php echo $this->form->getLabel('letter_name'); ?></div>				
                    <div class="controls">
                    <?php echo $this->form->getInput('letter_name'); ?>
                    </div>
                    </br>
                    <div class="control-label"><?php echo 'Date'; ?></div>				
                    <div class="controls">
                    <?php echo $this->form->getInput('created'); ?>
                    
                    </div>

                </div>

                    </fieldset>
                </div>
                
                <div class="span3">
                    <?php echo LayoutHelper::render('joomla.edit.global', $this); ?>
                    <?php echo $this->form->getInput('rules'); ?>
                </div>
            </div>
            <?php echo HtmlHelper::_('bootstrap.endTab'); ?>
            
            

            <?php echo HtmlHelper::_('bootstrap.endTabSet'); ?>

            <input type="hidden" name="task" value="" />
            <?php echo HtmlHelper::_('form.token'); ?>

        </div>
    </form>