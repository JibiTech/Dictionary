<?php

\defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Factory;
use Joomla\CMS\WebAsset\WebAssetManager;

use Joomla\CMS\Button\PublishedButton;

$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));

//Get the assets - css and js - from the media folder using WebAssetManager
$this->document->getWebAssetManager()
	->useStyle('dictionary_css')
	->useStyle('list_css');


$user = Factory::getApplication()->getIdentity();
$userId = $user->id;
$canOrder = $user->authorise('core.edit.state', 'com_dictionary');
$saveOrder = $listOrder === 'a.ordering';

if ($saveOrder) {
    HTMLHelper::_('sortablelist.sortable', 'definitionList', 'adminForm', strtolower($listDirn), 'index.php?option=com_dictionary&task=definitions.saveOrderAjax&tmpl=component');
}

//$sortFields = $this->getSortFields();
?>
<script>
    Joomla.orderTable = function() {
        var table = document.getElementById("sortTable");
        var direction = document.getElementById("directionTable");
        var order = table.options[table.selectedIndex].value;
        var dirn = order !== '<?php echo $listOrder; ?>' ? 'asc' : direction.options[direction.selectedIndex].value;
        Joomla.tableOrdering(order, dirn, '');
    }
</script>

<form action="<?php echo Route::_('index.php?option=com_dictionary'); ?>" method="post" name="adminForm"
	id="adminForm">
    <?php if (!empty($this->sidebar)) : ?>
        <div id="j-sidebar-container" class="span2">
            <?php echo $this->sidebar; ?>
        </div>
        <div id="j-main-container" class="span10">
    <?php else : ?>
        <div id="j-main-container">
    <?php endif; ?>

	<?php echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>

	<div class="table-responsive">
		<table class="table table-striped">
			<caption>
				<?php echo Text::_('COM_DICTIONARY_DEFINITIONS_TABLE_CAPTION'); ?>
			</caption>
			<thead>
				<tr>
                    <th scope="col">
                        <?php echo HTMLHelper::_('grid.sort', '<i class="icon-menu-2"></i>', 'a.ordering', $listDirn, $listOrder, null, 'asc', 'JGRID_HEADING_ORDERING'); ?>
                    </th>
					<td class="w-1 text-center">
						<?php echo HTMLHelper::_('grid.checkall'); ?>
					</td>
                    <th scope="col" class="w-1 text-center">
						<?php echo HTMLHelper::_('searchtools.sort', 'JSTATUS', 'a.state', $listDirn, $listOrder); ?>
					</th>
					<th scope="col">
						<?php echo HTMLHelper::_('searchtools.sort', 'COM_DICTIONARY_DEFINITIONS_TITLE_LETTER', 'b.letter_name', $listDirn, $listOrder); ?>
					</th>
                    <th scope="col">
                        <?php echo HTMLHelper::_('searchtools.sort', 'COM_DICTIONARY_LETTERDEFINITIONS_CATEGORY_WORD', 'a.word', $listDirn, $listOrder); ?>
                    </th>					
					<th scope="col">
						<?php echo HTMLHelper::_('searchtools.sort', 'COM_DICTIONARY_DEFINITIONS_DEFINITION', 'a.definition', $listDirn, $listOrder); ?>
					</th>
					<th scope="col">
                        <?php echo HTMLHelper::_('searchtools.sort', 'Created', 'a.created', $listDirn, $listOrder); ?>
					</th>
					
				</tr>
			</thead>
			<tbody>
				<?php foreach ($this->items as $i => $item):
					$canChange = $user->authorise('core.edit.state', 'com_dictionary.definition.' . $item->id);
					?>
					<tr class="row<?php echo $i % 2; ?>">
                        <td class="order nowrap center hidden-phone">
                            <span class="sortable-handler hasTooltip">
                                <i class="icon-menu"></i>
                            </span>
                            <input type="text" style="display:none" name="order[]" value="<?php echo $item->ordering; ?>" class="width-20 text-area-order" />
                        </td>
						<td class="text-center">
							<?php echo HTMLHelper::_('grid.id', $i, $item->id, false, 'cid', 'cb', $item->word); ?>
						</td>
						<td class="article-status text-center">
							<?php
							$options = [
								'task_prefix' => 'definitions.',
								//'disabled' => $workflow_state || !$canChange,
								'id' => 'state-' . $item->id
							];

							echo (new PublishedButton)->render((int) $item->state, $i, $options);
							?>
						</td>
						<td>
						<?php echo $item->letter_name; ?>
						</td>
						<td>
							<a href="<?php echo Route::_('index.php?option=com_dictionary&task=definition.edit&id=' . $item->id); ?>"
								title="<?php echo Text::_('JACTION_EDIT'); ?> <?php echo $this->escape($item->word); ?>">
								<?php echo $this->escape($item->word); ?></a>
						</td>
						<td>
							<?php echo $item->definition; ?>
						</td>
						<td>
                            <span><?php echo HTMLHelper::_('date', $item->created, Text::_('DATE_FORMAT_LC4')); ?></span>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<?php echo $this->pagination->getListFooter(); ?>
	<input type="hidden" name="task" value="">
	<input type="hidden" name="boxchecked" value="0">
	<?php echo HTMLHelper::_('form.token'); ?>

</form>