<?php

/**
 * @package     Joomla.Plugin
 * @subpackage  Search.tags
 * @Author	    web-eau.net
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

/**
 * Tags search plugin.
 * @since  3.3
 */
class PlgSearchDictionary extends JPlugin
{
	/**
	 * Load the language file on instantiation.
	 * @var    boolean
	 * @since  3.3
	 */
	protected $autoloadLanguage = true;

	/**
	 * Determine areas searchable by this plugin.
	 * @return  array  An array of search areas.
	 * @since   3.3
	 */
	public function onContentSearchAreas()
	{
		static $areas = array(
			'Dictionary' => 'Dictionary'
		);

		return $areas;
	}

	/**
	 * Search content (tags).
	 * The SQL must return the following fields that are used in a common display
	 * routine: href, title, section, created, text, browsernav.
	 * @param   string  $text      Target search string.
	 * @param   string  $phrase    Matching option (possible values: exact|any|all).  Default is "any".
	 * @param   string  $ordering  Ordering option (possible values: newest|oldest|popular|alpha|category).  Default is "newest".
	 * @param   string  $areas     An array if the search is to be restricted to areas or null to search all areas.
	 * @return  array  Search results.
	 * @since   3.3
	 */
	public function onContentSearch($text, $phrase = '', $ordering = '', $areas = null)
	{
		$db    = JFactory::getDbo();
		$query = $db->getQuery(true);
		$app   = JFactory::getApplication();
		$user  = JFactory::getUser();
		$lang  = JFactory::getLanguage();
		$section = JText::_('Dictionary');
		$limit   = $this->params->def('search_limit', 50);

		if (is_array($areas) && !array_intersect($areas, array_keys($this->onContentSearchAreas())))
		{
			return array();
		}

		$text = trim($text);

		if ($text === '')
		{
			return array();
		}

		$text = $db->quote('%' . $db->escape($text, true) . '%', false);

		switch ($ordering)
		{
			case 'alpha':
				$order = 'a.word ASC';
				break;

			case 'newest':
				$order = 'a.created DESC';
				break;

			case 'oldest':
				$order = 'a.created ASC';
				break;

			case 'popular':
			default:
				$order = 'a.word DESC';
		}

		$query->select('a.id, a.word, a.definition, a.published, a.access'
			. ', a.checked_out, a.checked_out_time'		
			. ', a.created AS created, a.definition');

		/*$case_when_item_alias  = ' CASE WHEN ';
		$case_when_item_alias .= $query->charLength('a.alias', '!=', '0');
		$case_when_item_alias .= ' THEN ';
		$a_id                  = $query->castAsChar('a.id');
		$case_when_item_alias .= $query->concatenate(array($a_id, 'a.alias'), ':');
		$case_when_item_alias .= ' ELSE ';
		$case_when_item_alias .= $a_id . ' END as slug';
		$query->select($case_when_item_alias); */

		$query->from('#__dictionary_letter_def AS a');
		//$query->where('a.alias <> ' . $db->quote('root'));

		$query->where('(a.word LIKE ' . $text . ' OR a.definition LIKE ' . $text . ')');

		$query->where($db->qn('a.state') . ' = 1');

	/*	if (!$user->authorise('core.admin'))
		{
			$groups = implode(',', $user->getAuthorisedViewLevels());
			$query->where('a.access IN (' . $groups . ')');
		}

		if ($app->isClient('site') && JLanguageMultilang::isEnabled())
		{
			$tag = JFactory::getLanguage()->getTag();
			$query->where('a.language in (' . $db->quote($tag) . ',' . $db->quote('*') . ')');
		} */

		$query->order($order);

		$db->setQuery($query, 0, $limit);

		try
		{
			$rows = $db->loadObjectList();

		}
		catch (RuntimeException $e)
		{
			$rows = array();
			JFactory::getApplication()->enqueueMessage(JText::_('JERROR_AN_ERROR_HAS_OCCURRED'), 'error');
		}

		if ($rows)
		{
			
			//print_r($rows);
			//die;

			//JLoader::register('TagsHelperRoute', JPATH_SITE . '/components/com_dictionary/helpers/route.php');

			foreach ($rows as $key => $row)
			{
				$rows[$key]->href       = 'index.php?option=com_dictionary&view=letterdefinitions';
				$rows[$key]->text       = $row->definition;
				$rows[$key]->title      = $row->word;
				$rows[$key]->section    = $section;
				$rows[$key]->created    = $row->created;
				$rows[$key]->browsernav = 0;
			}
		}
		
		    $final_items = $rows;
			

			return $final_items;

	
	}
}
