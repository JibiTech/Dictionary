<?php

/**
 * @version     3.6.2
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net and updated by adedayo@jibitech.com
 **/
namespace Webeau\Component\Dictionary\Administrator\View\Import;


\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\GenericDataException;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Webeau\Component\Dictionary\Administrator\Helper\DictionaryHelper;

/**
 * View class for Dictionary Import.
 *
 * @since  4.0
 */
class HtmlView extends BaseHtmlView
{
    /**
	 * The model state
	 *
	 * @var  \Joomla\CMS\Object\CMSObject
	 */
	protected $state = null;

	/**
	 * The featured articles array
	 *
	 * @var  \stdClass[]
	 */
	protected $items = null;

	/**
	 * The pagination object.
	 *
	 * @var  \Joomla\CMS\Pagination\Pagination
	 */
	protected $pagination = null;
    
    /**
	 * Execute and display a template script.
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 */
	public function display($tpl = null)
	{
        $this->state      = $this->get('State');
		$this->items      = $this->get('Items');
		$this->pagination = $this->get('Pagination');
        
        // Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new GenericDataException(implode("\n", $errors), 500);
		}
        
        // Prepare the toolbar
        $this->addToolbar();

        $this->sidebar = HtmlHelper::_('sidebar.render');

        // Display the template
        parent::display($tpl);
    }
    
	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
    protected function addToolbarold(): void {
        $state = $this->get('State');
        $canDo = DictionaryHelper::getActions($state->get('filter.letter_id'));

        ToolbarHelper::title(Text::_('COM_DICTIONARY_TITLE_IMPORT'));

        $formPath = JPATH_COMPONENT_ADMINISTRATOR . '/views/letter';
        if (file_exists($formPath)) {
            if ($canDo->get('core.create')) {
                ToolbarHelper::apply('import.export', 'JTOOLBAR_EXPORT');
                ToolbarHelper::save('import.importcsv', 'JTOOLBAR_UPLOAD');
            }
        }

        if ($canDo->get('core.edit.state')) {
            if (isset($this->items[0]->state)) {
                ToolbarHelper::publish('import.publish', 'JTOOLBAR_PUBLISH', true);
                ToolbarHelper::unpublish('import.unpublish', 'JTOOLBAR_UNPUBLISH', true);
            } else if (isset($this->items[0])) {
                ToolbarHelper::deleteList('', 'import.delete', 'JTOOLBAR_DELETE');
            }
        }

        if ($canDo->get('core.admin')) {
            ToolbarHelper::preferences('com_dictionary');
        }

       DictionaryHelper::addSubmenu();// HTMLHelper::_('sidebar.setAction', 'index.php?option=com_dictionary&view=import');
        $this->extra_sidebar = '';
    }

    protected function addToolbar(): void
    {
        $app = Factory::getApplication();

		ToolbarHelper::title(Text::_('COM_DICTIONARY_TITLE_IMPORT'));
        // Get the toolbar object instance
		$toolbar = Toolbar::getInstance('toolbar');

		$user = Factory::getApplication()->getIdentity();

		if ($user->authorise('core.admin', 'com_dictionary')) {
            ToolbarHelper::apply('import.export', 'JTOOLBAR_EXPORT');
            ToolbarHelper::save('import.importcsv', 'JTOOLBAR_UPLOAD');
    
		}

        if ($user->authorise('core.edit.state', 'com_dictionary')) {
            if (isset($this->items[0]->state)) {
                ToolbarHelper::publish('import.publish', 'JTOOLBAR_PUBLISH', true);
                ToolbarHelper::unpublish('import.unpublish', 'JTOOLBAR_UNPUBLISH', true);
            } else if (isset($this->items[0])) {
                ToolbarHelper::deleteList('', 'import.delete', 'JTOOLBAR_DELETE');
            }
        }

        if ($user->authorise('core.admin', 'com_dictionary') || $user->authorise('core.options', 'com_dictionary')) {
			$toolbar->preferences('com_dictionary');
		}

        HTMLHelper::_('sidebar.setAction', 'index.php?option=com_dictionary&view=import');
        $this->extra_sidebar = '';

        $tmpl = $app->input->getCmd('tmpl');
		if ($tmpl !== 'component') {
			ToolbarHelper::help('dictionary', true);
		}
    }
}