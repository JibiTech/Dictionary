<?php

/**
 * @version     3.6.2
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net and updated by adedayo@jibitech.com
 **/

namespace Webeau\Component\Dictionary\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Router\Route;
use Joomla\Input\Input;
use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;
use Exception;
use RuntimeException;


/**
 * Import controller class.
 *
 * @since  1.6
 */
class ImportController extends AdminController
{
	protected DatabaseInterface $db;
	protected $container;
    protected $user;
	/**
	 * Constructor.
	 *
	 * @param   array                $config   An optional associative array of configuration settings.
	 * Recognized key values include 'name', 'default_task', 'model_path', and
	 * 'view_path' (this list is not meant to be comprehensive).
	 * @param   MVCFactoryInterface  $factory  The factory.
	 * @param   CMSApplication       $app      The Application for the dispatcher
	 * @param   Input                $input    Input
	 *
	 * @since   3.0
	 */
	public function __construct($config = array(), MVCFactoryInterface $factory = null, $app = null, $input = null)
	{
		
		$container = Factory::getContainer();
        $this->db = $container->get('DatabaseDriver');
        $this->user = Factory::getApplication()->getIdentity();
		
		parent::__construct($config, $factory, $app, $input);

	}

	/**
	 * Proxy for getModel.
	 *
	 * @param   string  $name    The model name. Optional.
	 * @param   string  $prefix  The class prefix. Optional.
	 * @param   array   $config  The array of possible config values. Optional.
	 *
	 * @return  \Joomla\CMS\MVC\Model\BaseDatabaseModel
	 *
	 * @since   1.6
	 */
	public function getModel($name = 'Import', $prefix = 'Administrator', $config = array('ignore_request' => true))
	{
		return parent::getModel($name, $prefix, $config);
	}
	//derived from old code
	/**
     * Export data to a CSV file.
     */
    public function export(): void
    {
        function generateCsv(array &$export): string
        {
            if (count($export)) {
                ob_start();
                $df = fopen("php://output", 'w');
                foreach ($export as $row) {
                    fputcsv($df, $row);
                }
                fclose($df);
                return ob_get_clean();
            }

            return '';
        }

        // Query the database for data
        $query = $this->db->getQuery(true)
            ->select('a.id, a.letter_name, b.word, b.definition')
            ->from($this->db->quoteName('#__dictionary_letters', 'a'))
            ->join('INNER', $this->db->quoteName('#__dictionary_letter_def', 'b') . ' ON a.id = b.letter_id');

        $results = $this->db->setQuery($query)->loadObjectList();

        // Prepare data for CSV export
        $csv_export = [];
        foreach ($results as $i => $result) {
            $csv_export[] = [$i, $result->id, $result->letter_name, $result->word, $result->definition];
        }

        // Add headers to CSV
        $fields = ["Id", "Letter id", "Letter Name", "Word", "Definition"];
        array_unshift($csv_export, $fields);

        // Set headers for CSV download
        $filename = "Dictionary-Export-" . date("d-m-Y") . ".csv";
        header('Content-Encoding: UTF-8');
        header("Content-Type: application/csv;charset=UTF-8");
        header("Content-Disposition: attachment;filename={$filename}");
        
        // Output the CSV
        echo generateCsv($csv_export);
        exit;
    }

    /**
     * Import data from CSV.
     */
    public function importcsv(): void
    {
        try {
            // Get the uploaded file info
            $file = $this->input->files->get('fileupload');

            // Validate file upload
            if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
                throw new RuntimeException(Text::_('JERROR_UPLOAD_FAILED'));
            }
            
            $fileName = $file['name'];
            $uploadPath = JPATH_COMPONENT_ADMINISTRATOR . '/uploads/' . $fileName;

            // Move the file to the desired location
            if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
                throw new RuntimeException(Text::_('JERROR_UPLOAD_FAILED_MOVE'));
            }

            //Send to the model for file and database processing
            $model = $this->getModel('Import');

            try{ 
               if($model->processImport($uploadPath)){

                // Delete the uploaded file
                unlink($uploadPath);
                
                $this->setRedirect(Route::_('index.php?option=com_dictionary&view=definitions', false));                
               }
               else{ 
                throw new RuntimeException(Text::_('Error importing file. Please wait a few minutes and try again.')); 
                }
            }
            catch (Exception $e) {
                Factory::getApplication()->enqueueMessage(Text::_('JERROR_AN_ERROR_HAS_OCCURRED') . ': ' . $e->getMessage(), 'error');
            }

        } catch (Exception $e) {
            Factory::getApplication()->enqueueMessage(Text::_('JERROR_AN_ERROR_HAS_OCCURRED') . ': ' . $e->getMessage(), 'error');
        }
    }
}
