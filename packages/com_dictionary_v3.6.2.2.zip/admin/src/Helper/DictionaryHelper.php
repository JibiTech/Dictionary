<?php

/**
 * @version     3.6.2
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net and updated by adedayo@jibitech.com
 **/
namespace Webeau\Component\Dictionary\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Object\CMSObject;
use Joomla\Database\DatabaseDriver;
use Joomla\CMS\Log\Log;

/**
 * Dictionary helper class.
 */
class DictionaryHelper
{
    /**
     * Configure the Linkbar.
     */
    public static function addSubmenu(string $vName = ''): void
    {
        HTMLHelper::_('sidebar.addEntry', Text::_('COM_DICTIONARY_TITLE_LETTERS'), 'index.php?option=com_dictionary&view=letters', $vName === 'letters');
        HTMLHelper::_('sidebar.addEntry', Text::_('COM_DICTIONARY_TITLE_DEFINITIONS'), 'index.php?option=com_dictionary&view=definitions', $vName === 'definitions');
        HTMLHelper::_('sidebar.addEntry', Text::_('COM_DICTIONARY_TITLE_IMPORT'), 'index.php?option=com_dictionary&view=import', $vName === 'import');
    }

    /**
     * Gets a list of the actions that can be performed.
     *
     * @return CMSObject
     * @since 1.6
     */
    public static function getActions(): CMSObject
    {
        $user =  Factory::getApplication()->getIdentity();
        $result = new CMSObject;
        $assetName = 'com_dictionary';

        $actions = [
            'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
        ];

        foreach ($actions as $action) {
            $result->set($action, $user->authorise($action, $assetName));
        }

        return $result;
    }

    protected function getSortFields()
	{
		return array(
		'a.letter_name' => Text::_('COM_DICTIONARY_CATEGORIES_LETTER_NAME'),
		);
	}

    /**
     * Display a batch widget for the client selector.
     *
     * @return  string  The necessary HTML for the widget.
     *
     * @since   2.5
     */
    public static function clients(): string
    {
        HTMLHelper::_('bootstrap.tooltip');

        // Create the batch selector to change the client on a selection list.
        return implode(
            "\n",
            [
                '<label id="batch-client-lbl" for="batch-client" class="hasTooltip" title="'
                    . HTMLHelper::_('tooltipText', 'COM_LETTERS_BATCH_CLIENT_LABEL', 'COM_LETTERS_BATCH_CLIENT_LABEL_DESC')
                    . '">',
                Text::_('COM_LETTERS_BATCH_CLIENT_LABEL'),
                '</label>',
                '<select name="batch[client_id]" id="batch-client-id">',
                '<option value="">' . Text::_('COM_LETTERS_BATCH_CLIENT_NOCHANGE') . '</option>',
                '<option value="0">' . Text::_('COM_LETTERS_NO_CLIENT') . '</option>',
                HTMLHelper::_('select.options', static::clientlist(), 'value', 'text'),
                '</select>'
            ]
        );
    }

    /**
     * Method to get the field options.
     *
     * @return  array  The field option objects.
     *
     * @since   1.6
     */
    public static function clientlist(): array
    {
        /** @var DatabaseDriver $db */
        $container = Factory::getContainer();
        $db = $container->get('DatabaseDriver');
        $query = $db->getQuery(true)
            ->select('id AS value, name AS text')
            ->from($db->quoteName('#__banner_clients', 'a'))
            ->order('a.name');

        try {
            // Get the options.
            return $db->loadObjectList() ?? [];
        } catch (\RuntimeException $e) {
            Log::add($e->getMessage(), Log::WARNING, 'jerror');
            return [];
        }
    }

    /**
     * Returns a pinned state on a grid.
     *
     * @param   int     $value     The state value.
     * @param   int     $i         The row index.
     * @param   bool    $enabled   An optional setting for access control on the action.
     * @param   string  $checkbox  An optional prefix for checkboxes.
     *
     * @return  string   The Html code.
     *
     * @see     HTMLHelper::state
     * @since   2.5.5
     */
    public static function pinned(int $value, int $i, bool $enabled = true, string $checkbox = 'cb'): string
    {
        $states = [
            1 => [
                'sticky_unpublish',
                'COM_LETTERS_LETTERS_PINNED',
                'COM_LETTERS_LETTERS_HTML_PIN_BANNER',
                'COM_LETTERS_LETTERS_PINNED',
                true,
                'publish',
                'publish'
            ],
            0 => [
                'sticky_publish',
                'COM_LETTERS_LETTERS_UNPINNED',
                'COM_LETTERS_LETTERS_HTML_UNPIN_BANNER',
                'COM_LETTERS_LETTERS_UNPINNED',
                true,
                'unpublish',
                'unpublish'
            ],
        ];

        return HTMLHelper::_('jgrid.state', $states, $value, $i, 'letters.', $enabled, true, $checkbox);
    }
}
