<?php

/**
 * @version     3.6.2
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net and updated by adedayo@jibitech.com
 **/


\defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Factory;

$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));

//Get the assets - css and js - from the media folder using WebAssetManager
$this->document->getWebAssetManager()
	->useStyle('dictionary_css')
	->useStyle('list_css');


$user = Factory::getApplication()->getIdentity();
$userId = $user->id; $userName = $user->name;
$canOrder = $user->authorise('core.edit.state', 'com_dictionary');
$saveOrder = $listOrder === 'a.ordering';
if ($saveOrder)
{
	$saveOrderingUrl = 'index.php?option=com_dictionary&task=letters.saveOrderAjax&tmpl=component';
	HtmlHelper::_('sortablelist.sortable', 'letterList', 'adminForm', strtolower($listDirn), $saveOrderingUrl);
}
?>
<script type="text/javascript">
	Joomla.orderTable = function() {
		table = document.getElementById("sortTable");
		direction = document.getElementById("directionTable");
		order = table.options[table.selectedIndex].value;
		if (order != '<?php echo $listOrder; ?>') {
			dirn = 'asc';
		} else {
			dirn = direction.options[direction.selectedIndex].value;
		}
		Joomla.tableOrdering(order, dirn, '');
	}
</script>
<style type="text/css">
    .btn-group, .btn-group-vertical {
        display: inline-flex;
        position: relative;
        vertical-align: middle;
        margin-left: 5px;
    } 
    .dcnav .sidebar-nav {
        padding: 0;
        margin: 10px 0;
        background: #fff;
    }
    .dcnav .flex-column {
        flex-direction: row !important;
    }
    .dcnav .sidebar-nav li {
        font-size: .9rem;
        font-weight: 700;
        display: inline-block;
        margin: 0 5px;
        padding: 5px 10px;
    }
</style>
<?php
//Joomla Component Creator code to allow adding non select list filters
if (!empty($this->extra_sidebar)) {
    $this->sidebar .= $this->extra_sidebar;
}
?>

<form action="<?php echo Route::_('index.php?option=com_dictionary&view=letters'); ?>" method="post" name="adminForm" id="adminForm">
    <?php if(!empty($this->sidebar)): ?>
        <div id="j-sidebar-container" class="span2 dcnav">
            <?php echo $this->sidebar; ?>
        </div>
        <div id="j-main-container" class="span10">
    <?php else : ?>
        <div id="j-main-container">
    <?php endif;?>

            <?php echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>

            <div class="clearfix"> </div>
            <table class="table table-striped" id="letterList">
                <thead>
                    <tr>
                    <?php if (isset($this->items[0]->ordering)): ?>
                        <th width="1%" class="nowrap center hidden-phone">
                            <?php echo HtmlHelper::_('grid.sort', '<i class="icon-menu-2"></i>', 'a.ordering', $listDirn, $listOrder, null, 'asc', 'JGRID_HEADING_ORDERING'); ?>
                        </th>
                    <?php endif; ?>
                        <th width="1%" class="hidden-phone">
                            <input type="checkbox" name="checkall-toggle" value="" title="<?php echo Text::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)" />
                        </th>
                    <?php if (isset($this->items[0]->state)): ?>
                        <th width="1%" class="nowrap center">
                            <?php echo HtmlHelper::_('grid.sort', 'JSTATUS', 'a.state', $listDirn, $listOrder); ?>
                        </th>
                    <?php endif; ?>
                        
                        <th class='left'>
                            <?php echo HtmlHelper::_('grid.sort',  'COM_DICTIONARY_CATEGORIES_LETTER_NAME', 'a.letter_name', $listDirn, $listOrder); ?>
                        </th>
                        
                        <th width="10%" class="nowrap hidden-phone">
                            <?php echo HtmlHelper::_('searchtools.sort',  'JGRID_HEADING_ACCESS', 'a.access', $listDirn, $listOrder); ?>
                        </th>
                        
                        <th width="10%" class="nowrap hidden-phone">
                            <?php echo HtmlHelper::_('grid.sort', 'COM_DICTIONARY_DEFINITIONS_CREATED', 'a.created', $listDirn, $listOrder); ?>
                        </th>				 
                        
                    <?php if (isset($this->items[0]->id)): ?>
                        <th width="1%" class="nowrap center hidden-phone">
                            <?php echo HtmlHelper::_('grid.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>
                        </th>
                    <?php endif; ?>
                    </tr>
                </thead>
                <tfoot>
                    <?php 
                        if(isset($this->items[0])){
                            $colspan = count(get_object_vars($this->items[0]));
                        }
                        else{
                            $colspan = 10;
                        }
                    ?>
                    <tr>
                        <td colspan="<?php echo $colspan ?>">
                            <?php echo $this->pagination->getListFooter(); ?>
                        </td>
                    </tr>
                </tfoot>
                <tbody>
                    <?php foreach ($this->items as $i => $item) :
                        $ordering   = ($listOrder == 'a.ordering');
                        $canCreate	= $user->authorise('core.create',		'com_dictionary');
                        $canEdit	= $user->authorise('core.edit',			'com_dictionary');
                        $canCheckin	= $user->authorise('core.manage',		'com_dictionary');
                        $canChange	= $user->authorise('core.edit.state',	'com_dictionary');
                    ?>
                    <tr class="row<?php echo $i % 2; ?>">
                        
                    <?php if (isset($this->items[0]->ordering)): ?>
                        <td class="order nowrap center hidden-phone">
                        <?php if ($canChange) :
                            $disableClassName = '';
                            $disabledLabel	  = '';
                            if (!$saveOrder) :
                                $disabledLabel    = Text::_('JORDERINGDISABLED');
                                $disableClassName = 'inactive tip-top';
                            endif; 
                        ?>
                            <span class="sortable-handler hasTooltip <?php echo $disableClassName?>" title="<?php echo $disabledLabel?>">
                                <i class="icon-menu"></i>
                            </span>
                            <input type="text" style="display:none" name="order[]" size="5" value="<?php echo $item->ordering;?>" class="width-20 text-area-order " />
                        <?php else : ?>
                            <span class="sortable-handler inactive" >
                                <i class="icon-menu"></i>
                            </span>
                        <?php endif; ?>
                        </td>
                    <?php endif; ?>
                        <td class="center hidden-phone">
                            <?php echo HtmlHelper::_('grid.id', $i, $item->id); ?>
                        </td>
                    <?php if (isset($this->items[0]->state)): ?>
                        <td class="center">
                            <?php echo HtmlHelper::_('jgrid.published', $item->state, $i, 'letters.', $canChange, 'cb'); ?>
                        </td>
                    <?php endif; ?>
                        
                        <td>
                        <?php if (isset($item->checked_out) && $item->checked_out) : ?>
                            <?php echo HtmlHelper::_('jgrid.checkedout', $i, $userName, $item->checked_out_time, 'letters.', $canCheckin); ?>
                        <?php endif; ?>
                        <?php if ($canEdit) : ?>
                            <a href="<?php echo Route::_('index.php?option=com_dictionary&task=letter.edit&id='.(int) $item->id); ?>">
                            <?php echo $this->escape($item->letter_name); ?></a>
                        <?php else : ?>
                            <?php echo $this->escape($item->letter_name); ?>
                        <?php endif; ?>
                        </td>
                        <td class="small hidden-phone">
                        <?php 
                            if($item->access == 1) {
                            $access_level = 'Public' ;	
                            } else if($item->access == 2) {
                                $access_level = 'Registered' ;
                            } else if($item->access == 3) {
                                $access_level = 'Special' ;
                            } else if($item->access == 6) {
                                $access_level = 'Super Users' ;
                            } else if($item->access == 5) {
                                $access_level = 'Guest' ;
                            } 
                        ?>
                        <?php echo $access_level; ?>
                        </td>
                        <td class="hidden-phone center">
                            <span class="badge badge-info" style="color: #333;">
                                <?php $date = $item->created; ?>
                            <?php	echo $date > 0 ? HtmlHelper::_('date', $date, Text::_('DATE_FORMAT_LC4')) : '-'; ?>
                            </span>
                        </td>		
                    <?php if (isset($this->items[0]->id)): ?>
                        <td class="center hidden-phone">
                            <?php echo (int) $item->id; ?>
                        </td>
                    <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <input type="hidden" name="task" value="" />
            <input type="hidden" name="boxchecked" value="0" />
            <input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
            <input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>" />
            <?php echo HtmlHelper::_('form.token'); ?>
        </div>
</form>   