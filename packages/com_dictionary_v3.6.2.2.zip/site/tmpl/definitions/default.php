<?php

/**
 * @version     3.6.2
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net and updated by adedayo@jibitech.com
 **/

// No direct access
\defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Component\ComponentHelper;
use Webeau\Component\Dictionary\Administrator\Helper\DictionaryHelper;
use Joomla\CMS\Language\Text;

use Joomla\CMS\Router\Route;
use Joomla\CMS\Application\CMSApplication;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');
DictionaryHelper::class;
$container = Factory::getContainer();
/*
 * Alias the session service keys to the web session service as that is the primary session backend for this application.
 *
 * In addition to aliasing "common" service keys, we also create aliases for the PHP classes to ensure autowiring objects is supported.
 * This includes aliases for aliased class names, and the keys for aliased class names should be considered
 * deprecated to be removed when the class name alias is removed as well.
 */
$container->alias('session.web', 'session.web.site')
    ->alias('session', 'session.web.site')
    ->alias('JSession', 'session.web.site')
    ->alias(\Joomla\CMS\Session\Session::class, 'session.web.site')
    ->alias(\Joomla\Session\Session::class, 'session.web.site')
    ->alias(\Joomla\Session\SessionInterface::class, 'session.web.site');

// Instantiate the application.
$app = $container->get(\Joomla\CMS\Application\SiteApplication::class);
$doc = $app->getDocument();
$langd = $app->getLanguage()->getTag();
$lang = '';

if (Multilanguage::isEnabled()) {
    $lang = !is_null($langd) && $langd != "*" ? " AND (language='" . $app->getLanguage()->getTag() . "' OR language='*')" : "'*'";
}

/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $this->document->getWebAssetManager();
$wa->useStyle('dictionary_css')
    ->useScript('custom_js')
    ->useStyle('custom_css');

//To call the parameters from the backend component options
$params1 = ComponentHelper::getParams('com_dictionary');
$tviewfromoptions = $params1->get('show_template');
//Factory::getApplication()->enqueueMessage(Text::_('tview from component is ' . $tviewfromoptions));
//To call the parameters from the menu

// Get the active menu item
$menu = Factory::getApplication()->getMenu()->getActive();

if ($menu) {
    // Get the menu parameters
    $params2 = $menu->getParams();

    // Example: Retrieve a custom parameter named 'show_template'
    $tview = $params2->get('show_template', $tviewfromoptions); // Use the default options value as the fallback value
    //Factory::getApplication()->enqueueMessage(Text::_('tview from menu is ' . $tview));
}
else
{
    $tview = $tviewfromoptions;
}

?>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<?php


$db = $container->get('DatabaseDriver');
$query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__dictionary_letters'))
            ->where($db->quoteName('state') . ' = 1')
            ->order($db->quoteName('letter_name'));
$db->setQuery($query);
$r1 = $db->loadObjectList();
?>
<?php if (($tview == '0') || ($tview == '') ) : ?>
    <?php /* It means the display is wikipedia */ ?>
    <div class="atoz col-md-12">
        <div class='wiki-grid-container'>
            <?php $counter = 1; foreach ($r1 as $letter) : ?>
                <div class='wiki-letter-section'>
                    <h3 class='wiki-h2'><?php echo $letter->letter_name; ?></h3>
                    <?php
                    $query->clear()
                          ->select('*')
                          ->from($db->quoteName('#__dictionary_letter_def'))
                          ->where($db->quoteName('letter_id') . " = " . $db->quote($letter->id))
                          ->where($db->quoteName('state') . ' = 1' . $lang)
                          ->order('word');
                    $db->setQuery($query);
                    $r2 = $db->loadObjectList();
                    ?>
                    <ul class="wiki-ul">
                        <li>
                            <?php foreach ($r2 as $def) : ?>
                                <span class="wiki-word-item" onclick="toggleDefinition(this)">
                                    <?php echo $def->word; ?>
                                </span>
                                <span class="wiki-definition"><?php echo $def->definition; ?></span>
                                <br/>
                            <?php $counter++; endforeach; ?>
                        </li>
                    </ul>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <style>
        .atoz.col-md-12 {
            background: #fff;
            padding: 20px;
        }
    </style>

<?php else : ?>
    <style type="text/css">
        .atoz.col-md-12 {
        background: #fff;
        padding: 20px;
        width:  1024px;
        max-width: 100%;
        margin: auto;
        }
        .atoz .nav-pills {
            margin-left: 0!important;
        }
        .atoz .glossary-nav nav {
            padding: 0 48px 0 0;
            -webkit-transition: top 500ms ease 0s;
            -o-transition: top 500ms ease 0s;
            transition: top 500ms ease 0s;
        }
        .atoz .glossary-nav nav .nav-pills {
            background: #67707c;
        }
        .atoz .glossary-nav nav .nav-pills > li {
            border-right: 1px solid #ffffff;
            margin: 0;
        }
        .nav-pills>li {
            float: left;
        }
        .atoz .glossary-nav nav .nav-pills > li > a {
            padding: 8px 10px!important;
            font-size: 24px;
            line-height: normal;
            background: #67707c;
            color: #fff !important;
            font-weight: 600 !important;
            text-transform: uppercase;
            font-size: 15px;
        }
        .atoz .glossary-group-title {
            margin: 0 0 24px;
            font-weight: 600;
            font-size: 35px;
            background: #f6f8f8;
            color: #344150;
            padding: 10px 15px;
            text-transform: uppercase;
        }
        .atoz .glossary-group-items ul > li > a {
            color: #67707c !important;
            font-size: 18px;
            cursor: pointer;
        }
        .fade.in {
            opacity: 1;
        }
        .modal {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 1050;
            display: none;
            overflow: hidden;
            -webkit-overflow-scrolling: touch;
            outline: 0;
        }
        .modal-open .modal {
            overflow-x: hidden;
            overflow-y: auto;
        }
        .modal.in .modal-dialog {
            -webkit-transform: translate(0,0);
            -ms-transform: translate(0,0);
            -o-transform: translate(0,0);
            transform: translate(0,0);
        }
        .modal-dialog {
            position: relative;
            width: auto;
            margin: 10px;
        }
        .modal-content {
            -webkit-box-shadow: 0 5px 15px rgba(0,0,0,.5);
            box-shadow: 0 5px 15px rgba(0,0,0,.5);
        }
        .modal-content {
            position: relative;
            background-color: #fff;
            -webkit-background-clip: padding-box;
            background-clip: padding-box;
            border: 1px solid #999;
            border: 1px solid rgba(0,0,0,.2);
            border-radius: 6px;
            outline: 0;
            -webkit-box-shadow: 0 3px 9px rgba(0,0,0,.5);
            box-shadow: 0 3px 9px rgba(0,0,0,.5);
        }
        .dmodel .modal-header {
            padding: 15px;
            border-bottom: 1px solid #e5e5e5;
            display: block;
        }
        .modal-body {
            position: relative;
            padding: 15px;
        }
        .modal-backdrop.in {
            filter: alpha(opacity=50);
            opacity: .5;
        }
        .dmodel  .modal-dialog {
            position: relative;
            width: auto;
        margin: 50px auto;
        }
        .close {
            float: right;
            font-size: 21px;
            font-weight: 700;
            line-height: 1;
            color: #000;
            text-shadow: 0 1px 0 #fff;
            filter: alpha(opacity=20);
            opacity: .2;
        }
    </style> <br/><?php /* It means the display is list */ ?>
    <div class="atoz col-md-12">
        <div class="glossary-items">
            <div id="t3-content" class="t3-content col-xs-12">
                <div class="glossary-nav">
                    <nav class="affix-top">
                        <ul class="nav nav-pills">
                            <?php foreach ($r1 as $letter) : ?>
                                <li><a href="#<?php echo strtolower($letter->letter_name); ?>"><?php echo $letter->letter_name; ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </nav>
                </div>
                <div class="glossary-items">
                    <div class="glossary-group">
                        <?php foreach ($r1 as $letter) : ?>
                            <a name="<?php echo strtolower($letter->letter_name); ?>"></a>
                            <h3 class="glossary-group-title"><?php echo $letter->letter_name; ?></h3>
                            <div class="glossary-group-items">
                                <ul class="row">
                                    <?php
                                    $query->clear()
                                          ->select('*')
                                          ->from($db->quoteName('#__dictionary_letter_def'))
                                          ->where($db->quoteName('state') . ' = 1')
                                          ->where($db->quoteName('letter_id') . " = " . $db->quote($letter->id) . $lang)
                                          ->order('word');
                                    $db->setQuery($query);
                                    $definitions = $db->loadObjectList();
                                    ?>
                                    <?php foreach ($definitions as $definition) : ?>
                                        <?php $string = preg_replace('/\s+/', '', $definition->word); ?>
                                        <li class="col-xs-12 col-sm-6 col-md-3">
                                            <a type="button" data-toggle="modal" data-target="#myModal<?php echo $string; ?>">
                                                <?php echo $definition->word; ?>
                                            </a>
                                            <!-- Modal -->
                                            <div id="myModal<?php echo $string; ?>" class="dmodel modal fade" role="dialog">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                            <h4 class="modal-title"><?php echo $definition->word; ?></h4>
                                                        </div>
                                                        <div class="modal-body">
                                                            <?php echo $definition->definition; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .atoz .glossary-group-title {
            margin: 0 0 24px;
            font-weight: 600;
            font-size: 44px;
            background: #f6f8f8;
            color: #344150;
            padding: 10px 15px;
            text-transform: uppercase;
        }
        .atoz .glossary-group-items ul > li > a {
            color: #67707c;
            font-size: 18px;
            cursor: pointer;
        }
        .atoz .glossary-group-items ul > li {
            list-style: none;
            padding: 5px 15px;
            WIDTH: 29%;
            float: left;
        }
        .atoz .glossary-nav nav {
            padding: 0 48px 0 0;
            -webkit-transition: top 500ms ease 0s;
            -o-transition: top 500ms ease 0s;
            transition: top 500ms ease 0s;
        }
        .atoz .glossary-nav nav .nav-pills {
            background: #67707c;
        }
        .atoz .glossary-nav nav .nav-pills > li {
            border-right: 1px solid #ffffff;
            margin: 0;
        }
        .atoz .glossary-nav nav .nav-pills > li > a {
            padding: 8px 10px;
            font-size: 24px;
            line-height: normal;
            background: #67707c;
            color: #fff;
            font-weight: 600;
            text-transform: uppercase;
            font-size:15px;
        }
        .modal-body {
            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
            font-size: 14px;
            line-height: 1.42857143;
            color: #333; 
        }
        .atoz.col-md-12 {
            background: #fff;
            padding: 20px;
        }	
    </style>

<?php endif; ?>