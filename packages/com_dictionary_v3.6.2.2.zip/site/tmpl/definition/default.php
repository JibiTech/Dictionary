<?php

/**
 * @version     3.6.2
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net and updated by adedayo@jibitech.com
 **/

// No direct access
\defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Component\ComponentHelper;
use Webeau\Component\Dictionary\Administrator\Helper\DictionaryHelper;
use Joomla\CMS\Language\Text;

use Joomla\CMS\Router\Route;
use Joomla\CMS\Application\CMSApplication;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');
DictionaryHelper::class;
$container = Factory::getContainer();
/*
 * Alias the session service keys to the web session service as that is the primary session backend for this application.
 *
 * In addition to aliasing "common" service keys, we also create aliases for the PHP classes to ensure autowiring objects is supported.
 * This includes aliases for aliased class names, and the keys for aliased class names should be considered
 * deprecated to be removed when the class name alias is removed as well.
 */
$container->alias('session.web', 'session.web.site')
    ->alias('session', 'session.web.site')
    ->alias('JSession', 'session.web.site')
    ->alias(\Joomla\CMS\Session\Session::class, 'session.web.site')
    ->alias(\Joomla\Session\Session::class, 'session.web.site')
    ->alias(\Joomla\Session\SessionInterface::class, 'session.web.site');

// Instantiate the application.
$app = $container->get(\Joomla\CMS\Application\SiteApplication::class);
$doc = $app->getDocument();
$langd = $app->getLanguage()->getTag();
$lang = '';

if (Multilanguage::isEnabled()) {
    $lang = !is_null($langd) && $langd != "*" ? " AND (language='" . $app->getLanguage()->getTag() . "' OR language='*')" : "'*'";
}

/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $this->document->getWebAssetManager();
$wa->useStyle('dictionary_css')
    ->useScript('custom_js')
    ->useStyle('custom_css');

//Use the wiki display always
?>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<?php
    // Check if the item exists
    if (!isset($this->item) || empty($this->item)) {
        echo '<p>Definition not found.</p>';
        return;
    }

    // Assign variables for readability
    $item = $this->item;
?>
<div class="atoz col-md-12">
        <div class='wiki-grid-container'>
            
                <div class='wiki-letter-section'>
                    <h3 class='wiki-h2'><?php echo $item->word; ?></h3>
                    <span class=""><?php echo $item->definition; ?></span>
                </div>
            
        </div>
    </div>

    <style>
        .atoz.col-md-12 {
            background: #fff;
            padding: 20px;
        }
    </style>