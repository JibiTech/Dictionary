<?php

/**
 * @version     3.6.2
 * @package     com_dictionary search plugin
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net and updated by adedayo@jibitech.com
 **/

namespace Webeau\Component\Dictionary\Site\Helper;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

use Joomla\CMS\Categories\CategoryNode;
use Joomla\CMS\Language\Multilanguage;

/**
 * Dictionary Component Route Helper.
 *
 * @since  5.1
 */
abstract class RouteHelper
{
    /**
     * Get the URL route for a dictionary word from a dictionary ID, and language
     *
     * @param   integer  $id        The id of the contact
     * @param   integer  $catid     The id of the contact's category
     * @param   mixed    $language  The id of the language being used.
     *
     * @return  string  The link to the contact
     *
     * @since   1.5
     */
    public static function getDictionaryRoute($id, $language = null, $layout = null)
    {
        // Create the link
        $link = 'index.php?option=com_dictionary&view=definition&id=' . $id;

        /* since there is no category in the component
        if ($catid > 1) {
            $link .= '&catid=' . $catid;
        } */

        if (!empty($language) && $language !== '*' && Multilanguage::isEnabled()) {
            $link .= '&lang=' . $language;
        }

        if ($layout) {
            $link .= '&layout=' . $layout;
        }


        return (string)$link;
    }
}