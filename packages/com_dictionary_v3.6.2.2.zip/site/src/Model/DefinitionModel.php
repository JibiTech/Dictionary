<?php
/**
 * @version     3.6.2
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015 - 2024. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net and updated by adedayo@jibitech.com
 **/

 namespace Webeau\Component\Dictionary\Site\Model;

 defined('_JEXEC') or die;
 
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\MVC\Model\ItemModel;

class DefinitionModel extends ItemModel
{
    public function getItem($pk = null)
    {
        $id = $pk ?: $this->getState('definition.id');
        $db = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select('*')
            ->from('#__dictionary_letter_def')
            ->where('id = ' . (int) $id);
        $db->setQuery($query);
        
        return $db->loadObject();
    }

    protected function populateState()
    {
        $app = \Joomla\CMS\Factory::getApplication();
        $id = $app->input->getInt('id');
        $this->setState('definition.id', $id);
        parent::populateState();
    }
}
