/* For the new wikipedia frontend display */
function toggleDefinition(wordElement) {
    const definition = wordElement.nextElementSibling;
    definition.style.display = definition.style.display === 'block' ? 'none' : 'block';
}