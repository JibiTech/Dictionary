<?php

/**
 * @version     3.6.2
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net and updated by adedayo@jibitech.com
 **/

namespace Webeau\Component\Dictionary\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Database\DatabaseQueryInterface;
use RuntimeException;
use Joomla\Database\DatabaseInterface;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;


/**
 * Methods supporting the Dictionary import function.
 */
class ImportModel extends ListModel
{
    protected DatabaseInterface $db;
	protected $container;
    protected $user;
    /**
     * Constructor.
     *
     * @param array $config An optional associative array of configuration settings.
     */
    public function __construct($config = [], MVCFactoryInterface $factory= null)
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = [
                'id', 'a.id',
                'letter_name', 'a.letter_name',
            ];
        }
        $this->app = Factory::getApplication();
		$container = Factory::getContainer();
        $this->db = $container->get('DatabaseDriver');
        $this->user = Factory::getApplication()->getIdentity();
		
		parent::__construct($config, $factory);
    }

    /**
     * Build an SQL query to load the list data.
     *
     * @return DatabaseQueryInterface
     */
    protected function getListQuery()
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true);

        // Select required fields from the table.
        $query->select($this->getState('list.select', 'DISTINCT a.*'))
              ->from($db->quoteName('#__dictionary_letters', 'a'));

        return $query;
    }

    /**
     * Process the imported CSV file into the dictionary tables.
     * 
     * @param string $uploadPath   Folder location of file.
     * @throws RuntimeException If any error occurs during the database operations.
     */
    public function processImport(string $uploadPath): void
    {
        // Set file permissions
        chmod($uploadPath, 0777);     
        
        // Open and process the CSV file
        if (($handle = fopen($uploadPath, "r")) !== false) {
            $counter = 0;

            while (($data = fgetcsv($handle)) !== false) {
                if ($counter === 0) {
                    $counter++;
                    continue;
                }

                $letter_name = $data[0];
                $word = $data[1];
                $definition = $data[2];
                $userId = $this->user->id;
                $cdate = date("Y-m-d H:i:s");

                // Check if the letter exists
                $query = $this->db->getQuery(true)
                    ->select('id')
                    ->from($this->db->quoteName('#__dictionary_letters'))
                    ->where($this->db->quoteName('letter_name') . ' = ' . $this->db->quote($letter_name));

                $letterId = $this->db->setQuery($query)->loadResult();

                // Insert the letter if not found
                if (!$letterId) {
                    $insert_query = $this->db->getQuery(true)
                        ->insert($this->db->quoteName('#__dictionary_letters'))
                        ->columns($this->db->quoteName([
                            'letter_name', 'published', 'state', 
                            'checked_out', 'checked_out_time', 
                            'created', 'access', 'hits', 'ordering'
                        ]))
                        ->values(implode(',', [
                            $this->db->quote($letter_name),
                            1, 1,
                            /*$this->db->quote($userId)*/0,
                            $this->db->quote($cdate),
                            $this->db->quote($cdate),
                            1, 0, 0
                        ]));
                    $this->db->setQuery($insert_query)->execute();
                    $letterId = $this->db->insertid();
                }

                // Insert the definition
                $insert_definitions = $this->db->getQuery(true)
                    ->insert($this->db->quoteName('#__dictionary_letter_def'))
                    ->columns($this->db->quoteName([
                        'letter_id', 'word', 'definition', 
                        'published', 'state', 'checked_out', 
                        'checked_out_time', 'created', 'access', 
                        'hits', 'ordering'
                    ]))
                    ->values(implode(',', [
                        $this->db->quote($letterId),
                        $this->db->quote($word),
                        $this->db->quote($definition),
                        1, 1,
                        /*$this->db->quote($userId)*/0,
                        $this->db->quote($cdate),
                        $this->db->quote($cdate),
                        1, 0, 0
                    ]));

                $this->db->setQuery($insert_definitions)->execute();

                $counter++;
            }

            fclose($handle);
        }

    }
}