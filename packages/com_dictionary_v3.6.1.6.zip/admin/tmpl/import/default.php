<?php

/**
 * @version     3.6.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net Updated by adedayo@jibitech.com
 **/

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$user = Factory::getUser();
$userId = $user->get('id');

// Load custom CSS
$document = Factory::getDocument();
$document->getWebAssetManager()->useStyle('dictionary_css');
//Import css
$this->document->getWebAssetManager()
->useStyle('dictionary_css')
->useStyle('custom_css');
?>
<form action="<?php echo Route::_('index.php?option=com_dictionary&view=import'); ?>" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
    <?php if (!empty($this->sidebar)) : ?>
        <div id="j-sidebar-container" class="col-md-2 dcnav">
            <?php echo $this->sidebar; ?>
        </div>
        <div id="j-main-container" class="col-md-10">
    <?php else : ?>
        <div id="j-main-container">
    <?php endif; ?>
    
        <div class="clearfix"> </div>

        <!-- File upload field -->
        <div class="file-field">
            <div class="btn btn-primary btn-sm float-left">
                <span><?php echo Text::_('COM_DICTIONARY_IMPORT_CHOOSE_FILE'); ?></span>
                <input type="file" name="fileupload">
            </div>
            <div class="file-path-wrapper">
                <input type="hidden" name="task" value="import.importcsv" />
            </div>
        </div>

        <!-- Toolbar Filter (If Needed) -->
        <div id="filter-bar" class="btn-toolbar">
            <!-- Add any filter fields if applicable -->
        </div>

        <?php echo HTMLHelper::_('form.token'); ?>
    </div>
</form>
