<?php

/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net Updated by adedayo@jibitech.com
 **/


defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

HTMLHelper::_('stylesheet', 'components/com_dictionary/assets/css/dictionary.css');

$user = Factory::getApplication()->getIdentity();
$userId = $user->id;
$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');
$canOrder = $user->authorise('core.edit.state', 'com_dictionary');
$saveOrder = $listOrder === 'a.ordering';

if ($saveOrder) {
    HTMLHelper::_('sortablelist.sortable', 'letterdefinitionList', 'adminForm', strtolower($listDirn), 'index.php?option=com_dictionary&task=letterdefinitions.saveOrderAjax&tmpl=component');
}

$sortFields = $this->getSortFields();
?>
<script>
    Joomla.orderTable = function() {
        var table = document.getElementById("sortTable");
        var direction = document.getElementById("directionTable");
        var order = table.options[table.selectedIndex].value;
        var dirn = order !== '<?php echo $listOrder; ?>' ? 'asc' : direction.options[direction.selectedIndex].value;
        Joomla.tableOrdering(order, dirn, '');
    }
</script>

<form action="<?php echo Route::_('index.php?option=com_dictionary&view=letterdefinitions'); ?>" method="post" name="adminForm" id="adminForm">
    <?php if (!empty($this->sidebar)) : ?>
        <div id="j-sidebar-container" class="span2">
            <?php echo $this->sidebar; ?>
        </div>
        <div id="j-main-container" class="span10">
    <?php else : ?>
        <div id="j-main-container">
    <?php endif; ?>
    
    <div class="js-stools" role="search" style="float: right; margin: 10px 0;">
        <div class="btn-toolbar" id="filter-bar">
            <div class="btn-group">
                <input type="text" name="filter_search" id="filter_search" class="form-control" placeholder="<?php echo Text::_('JSEARCH_FILTER'); ?>" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" />
                <button type="submit" class="btn btn-primary" title="<?php echo Text::_('JSEARCH_FILTER_SUBMIT'); ?>">
                    <span class="icon-search" aria-hidden="true"></span>
                </button>
                <button type="button" class="btn btn-primary" title="<?php echo Text::_('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.getElementById('filter_search').value='';this.form.submit();">
                    <span class="icon-remove" aria-hidden="true"></span>
                </button>
            </div>
            
            <div class="btn-group">
                <select name="sortTable" id="sortTable" class="form-select" onchange="Joomla.orderTable()">
                    <option value=""><?php echo Text::_('JGLOBAL_SORT_BY'); ?></option>
                    <?php echo HTMLHelper::_('select.options', $sortFields, 'value', 'text', $listOrder); ?>
                </select>
            </div>
        </div>
    </div>
    
    <table class="table table-striped" id="letterdefinitionList">
        <thead>
            <tr>
                <th width="1%" class="nowrap center hidden-phone">
                    <?php echo HTMLHelper::_('grid.sort', '<i class="icon-menu-2"></i>', 'a.ordering', $listDirn, $listOrder, null, 'asc', 'JGRID_HEADING_ORDERING'); ?>
                </th>
                <th width="1%" class="hidden-phone">
                    <input type="checkbox" name="checkall-toggle" value="" title="<?php echo Text::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)" />
                </th>
                <th class="left">
                    <?php echo HTMLHelper::_('grid.sort', 'COM_DICTIONARY_LETTERDEFINITIONS_CATEGORY_WORD', 'a.word', $listDirn, $listOrder); ?>
                </th>
                <th class="left">
                    <?php echo HTMLHelper::_('grid.sort', 'COM_DICTIONARY_LETTERDEFINITIONS_WORD_DEFINITION', 'a.definition', $listDirn, $listOrder); ?>
                </th>
                <th width="10%" class="nowrap hidden-phone">
                    <?php echo HTMLHelper::_('grid.sort', 'Created', 'a.created', $listDirn, $listOrder); ?>
                </th>
            </tr>
        </thead>
        
        <tbody>
            <?php foreach ($this->items as $i => $item) : ?>
                <tr class="row<?php echo $i % 2; ?>">
                    <td class="order nowrap center hidden-phone">
                        <span class="sortable-handler hasTooltip">
                            <i class="icon-menu"></i>
                        </span>
                        <input type="text" style="display:none" name="order[]" value="<?php echo $item->ordering; ?>" class="width-20 text-area-order" />
                    </td>
                    <td class="center hidden-phone">
                        <?php echo HTMLHelper::_('grid.id', $i, $item->id); ?>
                    </td>
                    <td>
                        <?php echo $this->escape($item->word); ?>
                    </td>
                    <td>
                        <?php echo $this->escape($item->definition); ?>
                    </td>
                    <td class="center">
                        <span class="badge badge-info"><?php echo HTMLHelper::_('date', $item->created, Text::_('DATE_FORMAT_LC4')); ?></span>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <input type="hidden" name="task" value="" />
    <?php echo HTMLHelper::_('form.token'); ?>
</form>
