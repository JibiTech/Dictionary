<?php
/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015 - 2024. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net updated by adedayo@jibitech.com
 */

 defined('_JEXEC') or die;

 use Joomla\CMS\Factory;
 use Joomla\CMS\HTML\HTMLHelper;
 use Joomla\CMS\Language\Text;
 use Joomla\CMS\Layout\LayoutHelper;
 use Joomla\CMS\Router\Route;
 use Joomla\CMS\Uri\Uri;
 use Joomla\Database\DatabaseDriver;
 
 HTMLHelper::_('bootstrap.tooltip');
 HTMLHelper::_('behavior.formvalidator');
 HTMLHelper::_('bootstrap.startTabSet', 'myTab', ['active' => 'general']);
 HTMLHelper::_('bootstrap.addTab', 'myTab', 'general', Text::_('COM_DICTIONARY_TITLE_LETTERDEFINITION', true));
 
 $wa = $this->document->getWebAssetManager();
 $wa->useScript('keepalive')->useScript('form.validate');
 
 $document = Factory::getDocument();
 $document->addStyleSheet(Uri::root() . 'administrator/components/com_dictionary/assets/css/dictionary.css');
 
 // Database query to fetch dictionary letters
 $db = Factory::getDbo();
 $query = $db->getQuery(true)
             ->select('*')
             ->from($db->quoteName('#__dictionary_letters'));
 $db->setQuery($query);
 $results = $db->loadObjectList();
 $counter = count($results);
 
 $uid = $this->input->getInt('id');
 $query = $db->getQuery(true)
             ->select($db->quoteName('letter_id'))
             ->from($db->quoteName('#__dictionary_letter_def'))
             ->where($db->quoteName('id') . ' = ' . $db->quote($uid));
 $db->setQuery($query);
 $res = $db->loadResult();
 
 ?>
 <script type="text/javascript">
     Joomla.submitbutton = function(task) {
         if (task === 'letterdefinition.cancel') {
             Joomla.submitform(task, document.getElementById('letterdefinition-form'));
         } else if (document.formvalidator.isValid(document.getElementById('letterdefinition-form'))) {
             Joomla.submitform(task, document.getElementById('letterdefinition-form'));
         } else {
             alert('<?php echo Text::_('JGLOBAL_VALIDATION_FORM_FAILED'); ?>');
         }
     }
 </script>
 
 <form action="<?php echo Route::_('index.php?option=com_dictionary&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="letterdefinition-form" class="form-validate">
     <div class="form-horizontal">
         <div class="row">
             <div class="col-md-9 form-horizontal">
                 <fieldset class="adminform">
                     <input type="hidden" name="jform[id]" value="<?php echo (int) $this->item->id; ?>" />
 
                     <div class="control-group">
                         <div class="control-label">Select Letter *</div>
                         <div class="controls">
                             <select name="jform[letter_id]" id="jform_letter_id" class="form-select form-control-success">
                                 <?php foreach ($results as $result) : ?>
                                     <option value="<?php echo (int) $result->id; ?>" <?php echo ($result->id == $res) ? 'selected="selected"' : ''; ?>>
                                         <?php echo htmlspecialchars($result->letter_name, ENT_COMPAT, 'UTF-8'); ?>
                                     </option>
                                 <?php endforeach; ?>
                             </select>
                         </div>
                     </div>
 
                     <div class="control-group">
                         <div class="control-label"><?php echo $this->form->getLabel('word'); ?></div>
                         <div class="controls"><?php echo $this->form->getInput('word'); ?></div>
                     </div>
                     
                     <div class="control-group">
                         <div class="control-label">Date</div>
                         <div class="controls"><?php echo $this->form->getInput('created'); ?></div>
                     </div>
 
                     <div class="control-group">
                         <div class="control-label"><?php echo $this->form->getLabel('definition'); ?></div>
                         <div class="controls"><?php echo $this->form->getInput('definition'); ?></div>
                     </div>
                 </fieldset>
             </div>
             <div class="col-md-3">
                 <?php echo LayoutHelper::render('joomla.edit.global', $this); ?>
                 <?php echo $this->form->getInput('rules'); ?>
             </div>
         </div>
         <?php echo HTMLHelper::_('bootstrap.endTab'); ?>
         <?php echo HTMLHelper::_('bootstrap.endTabSet'); ?>
         
         <input type="hidden" name="task" value="" />
         <?php echo HTMLHelper::_('form.token'); ?>
     </div>
 </form>
 