<?php

/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net Updated by adedayo@jibitech.com
 **/

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;

// Load required scripts and CSS
$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
$wa->useScript('keepalive')
    ->useScript('form.validate')
    ->registerAndUseStyle('com_dictionary.dictionary', 'components/com_dictionary/assets/css/dictionary.css');

?>

<script type="text/javascript">
    Joomla.submitbutton = function(task) {
        if (task === 'letter.cancel') {
            Joomla.submitform(task, document.getElementById('letter-form'));
        } else {
            if (document.formvalidator.isValid(document.getElementById('letter-form'))) {
                Joomla.submitform(task, document.getElementById('letter-form'));
            } else {
                alert('<?php echo Text::_('JGLOBAL_VALIDATION_FORM_FAILED'); ?>');
            }
        }
    }
</script>

<form action="<?php echo Route::_('index.php?option=com_dictionary&layout=edit&id=' . (int) $this->item->id); ?>" 
      method="post" enctype="multipart/form-data" name="adminForm" id="letter-form" class="form-validate">

    <div class="row">
        <div class="col-md-9">
            <?php echo LayoutHelper::render('joomla.edit.title_alias', $this); ?>
            <fieldset>
                <div class="mb-3">
                    <?php echo $this->form->getLabel('letter_name'); ?>
                    <?php echo $this->form->getInput('letter_name'); ?>
                </div>
                <div class="mb-3">
                    <?php echo '<label>' . Text::_('COM_DICTIONARY_FIELD_DATE_LABEL') . '</label>'; ?>
                    <?php echo $this->form->getInput('created'); ?>
                </div>
            </fieldset>
        </div>

        <div class="col-md-3">
            <?php echo LayoutHelper::render('joomla.edit.global', $this); ?>
            <?php echo $this->form->getInput('rules'); ?>
        </div>
    </div>

    <input type="hidden" name="task" value="" />
    <?php echo HTMLHelper::_('form.token'); ?>
</form>
