<?php
/**
 * @version     3.6.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net Updated by adedayo@jibitech.com
 **/

 
// no direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

HtmlHelper::addIncludePath(JPATH_COMPONENT.'/helpers/html');
/*
JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');
*/

// Import CSS
HTMLHelper::_('stylesheet', 'components/com_dictionary/assets/css/dictionary.css');

$user	= Factory::getApplication()->getIdentity();
$userId	= $user->id;
$listOrder	= $this->state->get('list.ordering');
$listDirn	= $this->state->get('list.direction');
$canOrder	= $user->authorise('core.edit.state', 'com_dictionary');
$saveOrder	= $listOrder == 'a.ordering';
if ($saveOrder)
{
	$saveOrderingUrl = 'index.php?option=com_dictionary&task=letters.saveOrderAjax&tmpl=component';
	HtmlHelper::_('sortablelist.sortable', 'letterList', 'adminForm', strtolower($listDirn), $saveOrderingUrl);
}
$sortFields = $this->getSortFields();
?>
<script type="text/javascript">
	Joomla.orderTable = function() {
		table = document.getElementById("sortTable");
		direction = document.getElementById("directionTable");
		order = table.options[table.selectedIndex].value;
		if (order != '<?php echo $listOrder; ?>') {
			dirn = 'asc';
		} else {
			dirn = direction.options[direction.selectedIndex].value;
		}
		Joomla.tableOrdering(order, dirn, '');
	}
</script>
<style type="text/css">
    .btn-group, .btn-group-vertical {
        display: inline-flex;
        position: relative;
        vertical-align: middle;
        margin-left: 5px;
    } 
    .dcnav .sidebar-nav {
        padding: 0;
        margin: 10px 0;
        background: #fff;
    }
    .dcnav .flex-column {
        flex-direction: row !important;
    }
    .dcnav .sidebar-nav li {
        font-size: .9rem;
        font-weight: 700;
        display: inline-block;
        margin: 0 5px;
        padding: 5px 10px;
    }
</style>
<?php
//Joomla Component Creator code to allow adding non select list filters
if (!empty($this->extra_sidebar)) {
    $this->sidebar .= $this->extra_sidebar;
}
?>

<form action="<?php echo Route::_('index.php?option=com_dictionary&view=letters'); ?>" method="post" name="adminForm" id="adminForm">
<?php if(!empty($this->sidebar)): ?>
    <div id="j-sidebar-container" class="span2 dcnav">
        <?php echo $this->sidebar; ?>
    </div>
    <div id="j-main-container" class="span10">
<?php else : ?>
    <div id="j-main-container">
<?php endif;?>
        <div class="js-stools" role="search" style="float: right;    margin: 10px 0;">
            <div class="js-stools-container-bar">
                <div id="filter-bar" class="btn-toolbar">
                    <div class="filter-search-bar btn-group">
                        <div class="input-group">
		
		                    <input type="text" name="filter_search"   class="form-control" id="filter_search" placeholder="<?php echo Text::_('JSEARCH_FILTER'); ?>" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" title="<?php echo Text::_('JSEARCH_FILTER'); ?>" />
                            <div role="tooltip" id="filter_search-desc" class="filter-search-bar__description">
                                    Search in name letters.		
                            </div>
                            <span class="filter-search-bar__label visually-hidden">
                                <label id="filter_search-lbl" for="filter_search">
                                    Search Users
                                </label>
                            </span>
                            <button type="submit" class="filter-search-bar__button btn btn-primary" aria-label="Search" title="<?php echo Text::_('JSEARCH_FILTER_SUBMIT'); ?>">
                                <span class="filter-search-bar__button-icon icon-search" aria-hidden="true" ></span>
                            </button>
                            <button type="button" class="filter-search-bar__button btn btn-primary" type="button" title="<?php echo Text::_('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.getElementById('filter_search').value='';this.form.submit();">
                                <span class="filter-search-bar__button-icon icon-remove" aria-hidden="true"></span>
                            </button>
                        </div>
                    </div>
		
                    <div class="btn-group pull-right hidden-phone filter-search-actions ">
                        <label for="limit" class="element-invisible"><?php echo Text::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
                        <?php echo $this->pagination->getLimitBox(); ?>
                    </div>
                    <div class="btn-group pull-right hidden-phone filter-search-actions ">
                        <label for="directionTable" class="element-invisible"><?php echo Text::_('JFIELD_ORDERING_DESC');?></label>
                        <select name="directionTable" id="directionTable" class="form-select input-medium" onchange="Joomla.orderTable()">
                            <option value=""><?php echo Text::_('JFIELD_ORDERING_DESC');?></option>
                            <option value="asc" <?php if ($listDirn == 'asc') echo 'selected="selected"'; ?>><?php echo Text::_('JGLOBAL_ORDER_ASCENDING');?></option>
                            <option value="desc" <?php if ($listDirn == 'desc') echo 'selected="selected"'; ?>><?php echo Text::_('JGLOBAL_ORDER_DESCENDING');?></option>
                        </select>
                    </div>
                    <div class="btn-group pull-right filter-search-actions ">
                        <label for="sortTable" class="element-invisible"><?php echo Text::_('JGLOBAL_SORT_BY');?></label>
                        <select name="sortTable" id="sortTable" class="form-select input-medium" onchange="Joomla.orderTable()">
                            <option value=""><?php echo Text::_('JGLOBAL_SORT_BY');?></option>
                            <?php echo HtmlHelper::_('select.options', $sortFields, 'value', 'text', $listOrder);?>
                        </select>
                    </div>
                </div>
            </div>   
		</div>    
		<div class="clearfix"> </div>
		<table class="table table-striped" id="letterList">
			<thead>
				<tr>
                <?php if (isset($this->items[0]->ordering)): ?>
					<th width="1%" class="nowrap center hidden-phone">
						<?php echo HtmlHelper::_('grid.sort', '<i class="icon-menu-2"></i>', 'a.ordering', $listDirn, $listOrder, null, 'asc', 'JGRID_HEADING_ORDERING'); ?>
					</th>
                <?php endif; ?>
					<th width="1%" class="hidden-phone">
						<input type="checkbox" name="checkall-toggle" value="" title="<?php echo Text::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)" />
					</th>
                <?php if (isset($this->items[0]->state)): ?>
					<th width="1%" class="nowrap center">
						<?php echo HtmlHelper::_('grid.sort', 'JSTATUS', 'a.state', $listDirn, $listOrder); ?>
					</th>
                <?php endif; ?>
                    
                    <th class='left'>
                        <?php echo HtmlHelper::_('grid.sort',  'COM_DICTIONARY_CATEGORIES_LETTER_NAME', 'a.letter_name', $listDirn, $listOrder); ?>
                    </th>
                    
                    <th width="10%" class="nowrap hidden-phone">
                        <?php echo HtmlHelper::_('searchtools.sort',  'JGRID_HEADING_ACCESS', 'a.access', $listDirn, $listOrder); ?>
                    </th>
                    
                    <th width="10%" class="nowrap hidden-phone">
                        <?php echo HtmlHelper::_('grid.sort', 'Created', 'a.created', $listDirn, $listOrder); ?>
                    </th>				 
                    
                <?php if (isset($this->items[0]->id)): ?>
					<th width="1%" class="nowrap center hidden-phone">
						<?php echo HtmlHelper::_('grid.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>
					</th>
                <?php endif; ?>
                </tr>
            </thead>
			<tfoot>
                <?php 
                    if(isset($this->items[0])){
                        $colspan = count(get_object_vars($this->items[0]));
                    }
                    else{
                        $colspan = 10;
                    }
                ?>
                <tr>
                    <td colspan="<?php echo $colspan ?>">
                        <?php echo $this->pagination->getListFooter(); ?>
                    </td>
                </tr>
			</tfoot>
			<tbody>
			    <?php foreach ($this->items as $i => $item) :
                    $ordering   = ($listOrder == 'a.ordering');
                    $canCreate	= $user->authorise('core.create',		'com_dictionary');
                    $canEdit	= $user->authorise('core.edit',			'com_dictionary');
                    $canCheckin	= $user->authorise('core.manage',		'com_dictionary');
                    $canChange	= $user->authorise('core.edit.state',	'com_dictionary');
				?>
				<tr class="row<?php echo $i % 2; ?>">
                    
                <?php if (isset($this->items[0]->ordering)): ?>
					<td class="order nowrap center hidden-phone">
					<?php if ($canChange) :
						$disableClassName = '';
						$disabledLabel	  = '';
						if (!$saveOrder) :
							$disabledLabel    = Text::_('JORDERINGDISABLED');
							$disableClassName = 'inactive tip-top';
						endif; 
                    ?>
						<span class="sortable-handler hasTooltip <?php echo $disableClassName?>" title="<?php echo $disabledLabel?>">
							<i class="icon-menu"></i>
						</span>
						<input type="text" style="display:none" name="order[]" size="5" value="<?php echo $item->ordering;?>" class="width-20 text-area-order " />
					<?php else : ?>
						<span class="sortable-handler inactive" >
							<i class="icon-menu"></i>
						</span>
					<?php endif; ?>
					</td>
                <?php endif; ?>
					<td class="center hidden-phone">
						<?php echo HtmlHelper::_('grid.id', $i, $item->id); ?>
					</td>
                <?php if (isset($this->items[0]->state)): ?>
					<td class="center">
						<?php echo HtmlHelper::_('jgrid.published', $item->state, $i, 'letters.', $canChange, 'cb'); ?>
					</td>
                <?php endif; ?>
                    
                    <td>
                    <?php if (isset($item->checked_out) && $item->checked_out) : ?>
                        <?php echo HtmlHelper::_('jgrid.checkedout', $i, $item->editor, $item->checked_out_time, 'letters.', $canCheckin); ?>
                    <?php endif; ?>
                    <?php if ($canEdit) : ?>
                        <a href="<?php echo Route::_('index.php?option=com_dictionary&task=letter.edit&id='.(int) $item->id); ?>">
                        <?php echo $this->escape($item->letter_name); ?></a>
                    <?php else : ?>
                        <?php echo $this->escape($item->letter_name); ?>
                    <?php endif; ?>
                    </td>
                    <td class="small hidden-phone">
                    <?php 
                        if($item->access == 1) {
                        $access_level = 'Public' ;	
                        } else if($item->access == 2) {
                            $access_level = 'Registered' ;
                        } else if($item->access == 3) {
                            $access_level = 'Special' ;
                        } else if($item->access == 6) {
                            $access_level = 'Super Users' ;
                        } else if($item->access == 5) {
                            $access_level = 'Guest' ;
                        } 
                    ?>
                    <?php echo $access_level; ?>
                    </td>
                    <td class="hidden-phone center">
                        <span class="badge badge-info" style="color: #333;">
                            <?php $date = $item->created; ?>
                        <?php	echo $date > 0 ? HtmlHelper::_('date', $date, Text::_('DATE_FORMAT_LC4')) : '-'; ?>
                        </span>
                    </td>		
                <?php if (isset($this->items[0]->id)): ?>
					<td class="center hidden-phone">
						<?php echo (int) $item->id; ?>
					</td>
                <?php endif; ?>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
		<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>" />
		<?php echo HtmlHelper::_('form.token'); ?>
	</div>
</form>      