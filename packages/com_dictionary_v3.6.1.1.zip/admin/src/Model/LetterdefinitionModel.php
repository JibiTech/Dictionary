<?php
/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015 - 2024. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net updated by adedayo@jibitech.com
 */

 namespace Webeau\Component\Dictionary\Administrator\Model;

 defined('JPATH_PLATFORM') or die;

 use Joomla\CMS\Date\Date;
use Joomla\CMS\Event\AbstractEvent;
use Joomla\CMS\Factory;
use Joomla\CMS\Filter\InputFilter;
use Joomla\CMS\Filter\OutputFilter;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryInterface;
use Joomla\CMS\Helper\TagsHelper;
use Joomla\CMS\Language\Associations;
use Joomla\CMS\Language\LanguageHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\MVC\Model\WorkflowBehaviorTrait;
use Joomla\CMS\MVC\Model\WorkflowModelInterface;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\String\PunycodeHelper;
use Joomla\CMS\Table\TableInterface;
use Joomla\CMS\Tag\TaggableTableInterface;
use Joomla\CMS\UCM\UCMType;
use Joomla\CMS\Versioning\VersionableModelTrait;
use Joomla\CMS\Workflow\Workflow;
use Joomla\Component\Categories\Administrator\Helper\CategoriesHelper;
use Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use Joomla\Database\ParameterType;
use Joomla\Registry\Registry;
use Joomla\Utilities\ArrayHelper;

/**
 * Item Model for a Letter definition.
 *
 * @since  1.6
 */
class LetterdefinitionModel extends AdminModel
{
    /**
     * @var string The prefix to use with controller messages.
     */
    protected $text_prefix = 'COM_DICTIONARY';

    /**
     * Returns a reference to a Table object, always creating it.
     *
     * @param string $type   The table type to instantiate.
     * @param string $prefix A prefix for the table class name. Optional.
     * @param array  $config Configuration array for model. Optional.
     * @return Table A database object
     */
    /* public function getTable($type = 'Letterdefinition', $prefix = 'DictionaryTable', $config = [])
    {
        return Table::getInstance($type, $prefix, $config);
    } */
    /**
	 * Method to get a table object, load it if necessary.
	 *
	 * @param   string  $name     The table name. Optional.
	 * @param   string  $prefix   The class prefix. Optional.
	 * @param   array   $options  Configuration array for model. Optional.
	 *
	 * @return  Table  A Table object
	 *
	 * @since   3.0
	 * @throws  \Exception
	 */public function getTable($name = '', $prefix = '', $options = array())
	{
		$name = 'Letterdefinition';
		$prefix = 'DictionaryTable';

		if ($table = $this->_createTable($name, $prefix, $options))
		{
			return $table;
		}

		throw new \Exception(Text::sprintf('JLIB_APPLICATION_ERROR_TABLE_NAME_NOT_SUPPORTED', $name), 0);
	}

    /**
     * Method to get the record form.
     *
     * @param array   $data     An optional array of data for the form to interrogate.
     * @param boolean $loadData True if the form is to load its own data (default case), false if not.
     * @return Form|boolean A Form object on success, false on failure
     */
    public function getForm($data = [], $loadData = true)
    {
        $form = $this->loadForm('com_dictionary.letterdefinition', 'letterdefinition', ['control' => 'jform', 'load_data' => $loadData]);

        if (empty($form)) {
            return false;
        }

        return $form;
    }

    /**
     * Method to get the data that should be injected into the form.
     *
     * @return mixed The data for the form.
     */
    protected function loadFormData()
    {
        // Check the session for previously entered form data.
        $data = Factory::getApplication()->getUserState('com_dictionary.edit.letterdefinition.data', []);

        if (empty($data)) {
            $data = $this->getItem();
        }

        return $data;
    }

    /**
     * Method to get a single record.
     *
     * @param integer|null $pk The id of the primary key.
     * @return mixed Object on success, false on failure.
     */
    public function getItem($pk = null)
    {
        $item = parent::getItem($pk);

        // Do any processing on fields here if needed
        return $item;
    }

    /**
     * Prepare and sanitize the table prior to saving.
     *
     * @param Table $table The table object to prepare.
     */
    protected function prepareTable($table)
    {
        if (empty($table->id)) {
            // Set ordering to the last item if not set
            if ($table->ordering === '') {
                $db = $this->getDbo();
                $query = $db->getQuery(true)
                            ->select('MAX(ordering)')
                            ->from($db->quoteName('#__dictionary_letter_def'));
                $db->setQuery($query);
                $max = $db->loadResult();
                $table->ordering = $max + 1;
            }
        }
    }
}
