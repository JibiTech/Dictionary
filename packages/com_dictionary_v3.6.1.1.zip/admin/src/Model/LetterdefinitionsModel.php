<?php
/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015 - 2024. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net updated by adedayo@jibitech.com
 */

 namespace Webeau\Component\Dictionary\Administrator\Model;

 defined('JPATH_PLATFORM') or die;
 
 use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Database\DatabaseQuery;
use Joomla\CMS\Component\ComponentHelper;

/**
 * Methods supporting a list of Dictionary records.
 */
class LetterdefinitionsModel extends ListModel
{
    /**
     * Constructor.
     *
     * @param array $config An optional associative array of configuration settings.
     */
    public function __construct($config = [])
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = [
                'id', 'a.id',
                'letter_id', 'a.letter_id',
                'word', 'a.word',
                'definition', 'a.definition',
            ];
        }

        parent::__construct($config);
    }

    /**
     * Method to auto-populate the model state.
     *
     * Note: Calling getState in this method will result in recursion.
     */
    protected function populateState($ordering = 'a.word', $direction = 'asc')
    {
        $app = Factory::getApplication();

        // Load the filter state.
        $search = $app->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
        $this->setState('filter.search', $search);

        $published = $app->getUserStateFromRequest($this->context . '.filter.state', 'filter_published', '', 'string');
        $this->setState('filter.state', $published);

        // Load the parameters.
        $params = ComponentHelper::getParams('com_dictionary');
        $this->setState('params', $params);

        // List state information.
        parent::populateState($ordering, $direction);
    }

    /**
     * Method to get a store id based on model configuration state.
     *
     * This is necessary because the model is used by the component and
     * different modules that might need different sets of data or different
     * ordering requirements.
     *
     * @param string $id A prefix for the store id.
     * @return string A store id.
     */
    protected function getStoreId($id = '')
    {
        $id .= ':' . $this->getState('filter.search');
        $id .= ':' . $this->getState('filter.state');

        return parent::getStoreId($id);
    }

    /**
     * Build an SQL query to load the list data.
     *
     * @return DatabaseQuery
     */
    protected function getListQuery()
    {
        $db = $this->getDbo();
        $query = $db->getQuery(true);

        // Select the required fields from the table.
        $query->select($this->getState('list.select', 'DISTINCT a.*'))
            ->from($db->quoteName('#__dictionary_letter_def', 'a'));

        // Filter by search in title
        $search = $this->getState('filter.search');
        if (!empty($search)) {
            if (stripos($search, 'id:') === 0) {
                $query->where('a.id = ' . (int) substr($search, 3));
            } else {
                $search = '%' . $db->escape($search, true) . '%';
                $query->where('a.word LIKE ' . $db->quote($search));
            }
        }

        // Add the list ordering clause.
        $orderCol = $this->state->get('list.ordering', 'a.word');
        $orderDirn = $this->state->get('list.direction', 'ASC');
        $query->order($db->escape("$orderCol $orderDirn"));

        return $query;
    }

    /**
     * Method to get the items list.
     *
     * @return array The list of items.
     */
    public function getItems()
    {
        return parent::getItems();
    }
}