<?php
/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015 - 2024. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net updated by adedayo@jibitech.com
 */

 namespace Webeau\Component\Dictionary\Administrator\Model;

 defined('JPATH_PLATFORM') or die;

 use Joomla\CMS\Application\ApplicationHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\Database\DatabaseInterface;
use Joomla\CMS\Table\Table;
use Joomla\Utilities\ArrayHelper;

/**
 * Dictionary model for managing letters.
 */
class LetterModel extends AdminModel
{
    /**
     * @var string The prefix to use with controller messages.
     */
    protected $text_prefix = 'COM_DICTIONARY';

    /**
     * Returns a reference to a Table object, always creating it.
     *
     * @param string $type   The table type to instantiate.
     * @param string $prefix A prefix for the table class name. Optional.
     * @param array  $config Configuration array for model. Optional.
     * @return Table A database object
     */
    public function getTable($type = 'Letter', $prefix = 'DictionaryTable', $config = [])
    {
        return Table::getInstance($type, $prefix, $config);
    }

    /**
     * Method to get the record form.
     *
     * @param array   $data     An optional array of data for the form to interrogate.
     * @param boolean $loadData True if the form is to load its own data (default case), false if not.
     * @return Form|boolean A Form object on success, false on failure
     */
    public function getForm($data = [], $loadData = true)
    {
        $form = $this->loadForm('com_dictionary.letter', 'letter', ['control' => 'jform', 'load_data' => $loadData]);

        if (empty($form)) {
            return false;
        }

        return $form;
    }

    /**
     * Method to get the data that should be injected into the form.
     *
     * @return mixed The data for the form.
     */
    protected function loadFormData()
    {
        // Check the session for previously entered form data.
        $data = Factory::getApplication()->getUserState('com_dictionary.edit.letter.data', []);

        if (empty($data)) {
            $data = $this->getItem();
        }

        return $data;
    }

    /**
     * Method to get a single record.
     *
     * @param integer|null $pk The id of the primary key.
     * @return mixed Object on success, false on failure.
     */
    public function getItem($pk = null)
    {
        $item = parent::getItem($pk);

        // Do any processing on fields here if needed
        return $item;
    }

    /**
     * Prepare and sanitize the table prior to saving.
     *
     * @param Table $table The table object to prepare.
     */
    protected function prepareTable($table)
    {
        if (empty($table->id)) {
            // Set ordering to the last item if not set
            if ($table->ordering === '') {
                $db = $this->getDbo();
                $query = $db->getQuery(true)
                            ->select('MAX(ordering)')
                            ->from($db->quoteName('#__dictionary_letters'));
                $db->setQuery($query);
                $max = $db->loadResult();
                $table->ordering = $max + 1;
            }
        }
    }
}
