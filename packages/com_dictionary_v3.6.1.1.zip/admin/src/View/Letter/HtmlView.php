<?php

/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net Updated by adedayo@jibitech.com
 **/

 namespace Webeau\Component\Dictionary\Administrator\View\Letter;

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\Component\Dictionary\Administrator\Helper\DictionaryHelper;


/**
 * View to edit
 */
class DictionaryViewLetter extends BaseHtmlView
{
    protected $state;
    protected $item;
    protected $form;

    /**
     * Display the view
     */
    public function display($tpl = null)
    {
        $this->state = $this->get('State');
        $this->item = $this->get('Item');
        $this->form = $this->get('Form');

        // Check for errors
        if (count($errors = $this->get('Errors'))) {
            throw new \Exception(implode("\n", $errors));
        }

        $this->addToolbar();
        parent::display($tpl);
    }

    /**
     * Add the page title and toolbar.
     */
    protected function addToolbar()
    {
        //To resolve the JToolbarHelper issues
        if(!class_exists('JToolbarHelper')) {
            require_once JPATH_ADMINISTRATOR . '/includes/toolbar.php';
        }

        // Hide main menu during edit
        Factory::getApplication()->input->set('hidemainmenu', true);

        $user       = Factory::getUser();
        $userId     = $user->id;
        $isNew      = ($this->item->id == 0);
        $checkedOut = !(is_null($this->item->checked_out) || $this->item->checked_out == $userId);

        $canDo = DictionaryHelper::getActions();

        ToolbarHelper::title(Text::_('COM_DICTIONARY_TITLE_LETTER'), 'letter.png');

        // If not checked out, can save the item.
        if (!$checkedOut && ($canDo->get('core.edit') || $canDo->get('core.create'))) {
            ToolbarHelper::apply('letter.apply', 'JTOOLBAR_APPLY');
            ToolbarHelper::save('letter.save', 'JTOOLBAR_SAVE');
        }

        if (!$checkedOut && $canDo->get('core.create')) {
            ToolbarHelper::save2new('letter.save2new', 'JTOOLBAR_SAVE_AND_NEW');
        }

        // If an existing item, can save to a copy.
        if (!$isNew && $canDo->get('core.create')) {
            ToolbarHelper::save2copy('letter.save2copy', 'JTOOLBAR_SAVE_AS_COPY');
        }

        if (empty($this->item->id)) {
            ToolbarHelper::cancel('letter.cancel', 'JTOOLBAR_CANCEL');
        } else {
            ToolbarHelper::cancel('letter.cancel', 'JTOOLBAR_CLOSE');
        }
    }
}
