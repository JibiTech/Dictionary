<?php

/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net Updated by adedayo@jibitech.com
 **/

 namespace Webeau\Component\Dictionary\Administrator\View\Letters;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Language\Text;
use Joomla\Component\Dictionary\Administrator\Helper\DictionaryHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Exception;

// No direct access
defined('_JEXEC') or die;

/**
 * View class for a list of Dictionary letters.
 */
class DictionaryViewLetters extends BaseHtmlView
{
    protected $items;
    protected $pagination;
    protected $state;
    protected $sidebar;

    /**
     * Display the view
     *
     * @param string|null $tpl Template name
     * @throws Exception
     */
    public function display($tpl = null)
    {
        $this->state = $this->get('State');
        $this->items = $this->get('Items');
        $this->pagination = $this->get('Pagination');

        // Check for errors.
        if ($errors = $this->get('Errors')) {
            throw new Exception(implode("\n", $errors));
        }

        DictionaryHelper::addSubmenu('letters');

        $this->addToolbar();
        $this->sidebar = HTMLHelper::_('sidebar.render');

        parent::display($tpl);
    }

    /**
     * Add the page title and toolbar.
     *
     * @since 1.6
     */
    protected function addToolbar()
    {
        //require_once JPATH_COMPONENT . '/helpers/dictionary.php';

        $state = $this->get('State');
        $canDo = DictionaryHelper::getActions($state->get('filter.letter_id'));

        ToolbarHelper::title(Text::_('COM_DICTIONARY_TITLE_LETTERS'), 'letters.png');

        // Check if the form exists before showing the add/edit buttons
        $formPath = JPATH_COMPONENT_ADMINISTRATOR . '/views/letter/tmpl';
        if (file_exists($formPath)) {

            if ($canDo->get('core.create')) {
                ToolbarHelper::addNew('letter.add', 'JTOOLBAR_NEW');
                ToolbarHelper::apply('import.export', 'Export');
            }

            if ($canDo->get('core.edit') && isset($this->items[0])) {
                ToolbarHelper::editList('letter.edit', 'JTOOLBAR_EDIT');
            }
        }

        if ($canDo->get('core.edit.state')) {

            if (isset($this->items[0]->state)) {
                ToolbarHelper::divider();
                ToolbarHelper::publish('letters.publish', 'JTOOLBAR_PUBLISH', true);
                ToolbarHelper::unpublish('letters.unpublish', 'JTOOLBAR_UNPUBLISH', true);
            } else if (isset($this->items[0])) {
                // If this component does not use state then show a direct delete button as we can not trash
                ToolbarHelper::deleteList('', 'letters.delete', 'JTOOLBAR_DELETE');
            }

            if (isset($this->items[0]->state)) {
                ToolbarHelper::divider();
                // ToolbarHelper::archiveList('letters.archive', 'JTOOLBAR_ARCHIVE');
            }
            if (isset($this->items[0]->checked_out)) {
                ToolbarHelper::checkin('letters.checkin', 'JTOOLBAR_CHECKIN', true);
            }
        }

        // Show trash and delete for components that use the state field
        if (isset($this->items[0]->state)) {
            if ($state->get('filter.state') == -2 && $canDo->get('core.delete')) {
                ToolbarHelper::deleteList('', 'letters.delete', 'JTOOLBAR_EMPTY_TRASH');
                ToolbarHelper::divider();
            } else if ($canDo->get('core.edit.state')) {
                ToolbarHelper::trash('letters.delete', 'JTOOLBAR_DELETE');
                ToolbarHelper::divider();
            }
        }

        if ($canDo->get('core.admin')) {
            ToolbarHelper::preferences('com_dictionary');
        }

        // Set sidebar action - New in 3.0
        HTMLHelper::_('sidebar.setAction', 'index.php?option=com_dictionary&view=letters');

        $this->extra_sidebar = '';
    }

    protected function getSortFields()
    {
        return [
            'a.letter_name' => Text::_('COM_DICTIONARY_CATEGORIES_LETTER_NAME'),
        ];
    }
}
