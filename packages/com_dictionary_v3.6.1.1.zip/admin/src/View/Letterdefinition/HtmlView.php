<?php

/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net Updated by adedayo@jibitech.com
 **/

namespace Webeau\Component\Dictionary\Administrator\View\Letterdefinition;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Dictionary\Component\Dictionary\Administrator\Helper\DictionaryHelper;

/**
 * View to edit a letter definition
 */
class HtmlView extends BaseHtmlView {
    protected $state;
    protected $item;
    protected $form;

    /**
     * Display the view
     */
    public function display($tpl = null) {
        $this->state = $this->get('State');
        $this->item = $this->get('Item');
        $this->form = $this->get('Form');

        // Check for errors.
        if (count($errors = $this->get('Errors'))) {
            throw new \Exception(implode("\n", $errors));
        }

        $this->addToolbar();
        parent::display($tpl);
    }

    /**
     * Add the page title and toolbar.
     */
    protected function addToolbar() {
        $input = Factory::getApplication()->input;
        $input->set('hidemainmenu', true);

        $user = Factory::getUser();
        $userId = $user->id;
        $isNew = ($this->item->id == 0);
        $checkedOut = !is_null($this->item->checked_out) && $this->item->checked_out != $userId;

        $canDo = DictionaryHelper::getActions();

        ToolbarHelper::title(Text::_('COM_DICTIONARY_TITLE_LETTERDEFINITION'), 'letterdefinition');

        // If not checked out, can save the item.
        if (!$checkedOut && ($canDo->get('core.edit') || $canDo->get('core.create'))) {
            ToolbarHelper::apply('letterdefinition.apply');
            ToolbarHelper::save('letterdefinition.save');
        }
        if (!$checkedOut && $canDo->get('core.create')) {
            ToolbarHelper::save2new('letterdefinition.save2new');
        }
        // If an existing item, can save to a copy.
        if (!$isNew && $canDo->get('core.create')) {
            ToolbarHelper::save2copy('letterdefinition.save2copy');
        }
        if (empty($this->item->id)) {
            ToolbarHelper::cancel('letterdefinition.cancel', 'JTOOLBAR_CANCEL');
        } else {
            ToolbarHelper::cancel('letterdefinition.cancel', 'JTOOLBAR_CLOSE');
        }
    }
}
