<?php

/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net Updated by adedayo@jibitech.com
 **/

namespace Webeau\Component\Dictionary\Administrator\View\Import;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Webeau\Component\Dictionary\Administrator\Helper\DictionaryHelper;

// No direct access
defined('_JEXEC') or die;

/**
 * View class for a list of Dictionary Imports.
 */
class DictionaryViewImport extends BaseHtmlView {

    protected $items;
    protected $pagination;
    protected $state;

    public function display($tpl = null) {
        $this->state = $this->get('State');
        $this->items = $this->get('Items');
        $this->pagination = $this->get('Pagination');

        // Check for errors.
        if ($errors = $this->get('Errors')) {
            throw new \RuntimeException(implode("\n", $errors), 500);
        }

        DictionaryHelper::addSubmenu('Import');
        $this->addToolbar();

        $this->sidebar = HTMLHelper::_('sidebar.render');
        parent::display($tpl);
    }

    protected function addToolbar() {
        $state = $this->get('State');
        $canDo = DictionaryHelper::getActions($state->get('filter.letter_id'));

        ToolbarHelper::title(Text::_('COM_DICTIONARY_TITLE_IMPORT'), 'import');

        $formPath = JPATH_COMPONENT_ADMINISTRATOR . '/views/letter';
        if (file_exists($formPath)) {
            if ($canDo->get('core.create')) {
                ToolbarHelper::apply('import.export', 'JTOOLBAR_EXPORT');
                ToolbarHelper::save('import.importcsv', 'JTOOLBAR_UPLOAD');
            }
        }

        if ($canDo->get('core.edit.state')) {
            if (isset($this->items[0]->state)) {
                ToolbarHelper::publish('import.publish', 'JTOOLBAR_PUBLISH', true);
                ToolbarHelper::unpublish('import.unpublish', 'JTOOLBAR_UNPUBLISH', true);
            } else if (isset($this->items[0])) {
                ToolbarHelper::deleteList('', 'import.delete', 'JTOOLBAR_DELETE');
            }
        }

        if ($canDo->get('core.admin')) {
            ToolbarHelper::preferences('com_dictionary');
        }

        HTMLHelper::_('sidebar.setAction', 'index.php?option=com_dictionary&view=import');
        $this->extra_sidebar = '';
    }

    protected function getSortFields() {
        return [
            'a.letter_name' => Text::_('COM_DICTIONARY_CATEGORIES_LETTER_NAME'),
        ];
    }
}
