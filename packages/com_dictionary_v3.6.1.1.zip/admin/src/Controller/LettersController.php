<?php
/**
 * @version     3.6.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015 - 2024. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net, updated by adedayo@jibitech.com
 */

namespace Webeau\Component\Dictionary\Administrator\Controller;

// No direct access.
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\Utilities\ArrayHelper;

/**
 * Letters list controller class.
 */
class LettersController extends AdminController
{
    /**
     * Proxy for getModel.
     * 
     * @param string $name
     * @param string $prefix
     * @return \Joomla\CMS\MVC\Model\BaseDatabaseModel|boolean
     * @since 1.6
     */
    public function getModel($name = 'Letter', $prefix = 'DictionaryModel', $config = [])
    {
        return parent::getModel($name, $prefix, $config);
    }

    /**
     * Method to save the submitted ordering values for records via AJAX.
     * 
     * @return void
     * @since 3.0
     */
    public function saveOrderAjax()
    {
        // Check for request forgeries.
        Session::checkToken('post') or jexit(Text::_('JINVALID_TOKEN'));

        // Get the input
        $input = Factory::getApplication()->input;
        $pks   = $input->post->get('cid', [], 'array');
        $order = $input->post->get('order', [], 'array');

        // Sanitize the input
        ArrayHelper::toInteger($pks);
        ArrayHelper::toInteger($order);

        // Get the model
        $model = $this->getModel();

        // Save the ordering
        $return = $model->saveorder($pks, $order);

        echo ($return) ? "1" : "0";

        // Close the application
        Factory::getApplication()->close();
    }

    /**
     * Method to export dictionary data to CSV.
     * 
     * @return void
     */
    public function export()
    {
        // Define a function to generate the CSV
        function generatecsv(array &$export)
        {
            if (count($export)) {
                ob_start();
                $df = fopen("php://output", 'w');
                foreach ($export as $row) {
                    fputcsv($df, $row);
                }
                fclose($df);
                return ob_get_clean();
            }
        }

        // Database query
        $db    = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('a.id, a.letter_name, b.word, b.definition')
            ->from('#__dictionary_letters as a')
            ->leftJoin('#__dictionary_letter_def as b ON a.id = b.letter_id');
        $db->setQuery($query);
        $results = $db->loadObjectList();

        $csv_export = [];
        foreach ($results as $i => $result) {
            $csv_export[$i] = [$result->letter_name, $result->word, $result->definition];
        }

        $fields = ["Letter Name", "Word", "Definition"];
        array_unshift($csv_export, $fields);

        $filename = "Export-" . date("d-m-Y") . ".csv";

        header('Content-Encoding: UTF-8');
        header("Content-Type: application/csv;charset=UTF-8");
        header("Content-Disposition: attachment;filename={$filename}");
        echo generatecsv($csv_export);
        exit;
    }

    /**
     * Method to publish/unpublish records.
     * 
     * @param array $pks
     * @param int $state
     * @param int $userId
     * @return void
     */
    public function publish($pks = null, $state = 1, $userId = 0)
    {
        // Retrieve application and post data
        $app     = Factory::getApplication();
        $pks     = $app->input->post->get('cid', [], 'array');
        $task    = $app->input->getCmd('task');
        $user    = Factory::getUser();
        $userId  = $user->id;
        $state   = ($task == 'letters.unpublish') ? 0 : $state;

        // Sanitize input
        ArrayHelper::toInteger($pks);

        // Validate selected records
        if (empty($pks)) {
            $app->enqueueMessage(Text::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'), 'error');
            return $this->setRedirect(Route::_('index.php?option=com_dictionary&view=letters', false));
        }

        // Build the WHERE clause
        $where = 'id IN (' . implode(',', $pks) . ')';

        // Update the publishing state for rows with the given primary keys.
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->update($db->quoteName('#__dictionary_letters'))
            ->set('checked_out = ' . (int)$userId . ', state = ' . (int)$state)
            ->where($where);
        $db->setQuery($query);
        $db->execute();

        // Redirect based on task outcome
        $msg = Text::plural($state ? 'COM_DICTIONARY_N_ITEMS_PUBLISHED' : 'COM_DICTIONARY_N_ITEMS_UNPUBLISHED', count($pks));
        $this->setRedirect(Route::_('index.php?option=com_dictionary&view=letters', false), $msg);
    }

    /**
     * Method to delete records.
     * 
     * @return void
     */
    public function delete()
    {
        // Retrieve application and post data
        $app     = Factory::getApplication();
        $pks     = $app->input->post->get('cid', [], 'array');

        // Sanitize input
        ArrayHelper::toInteger($pks);

        // Validate selected records
        if (empty($pks)) {
            $app->enqueueMessage(Text::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'), 'error');
            return $this->setRedirect(Route::_('index.php?option=com_dictionary&view=letters', false));
        }

        // Build the WHERE clause
        $where = 'id IN (' . implode(',', $pks) . ')';

        // Execute delete query
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->delete($db->quoteName('#__dictionary_letters'))
            ->where($where);
        $db->setQuery($query);
        $db->execute();

        // Redirect after deletion
        $msg = Text::plural('COM_DICTIONARY_N_ITEMS_DELETED', count($pks));
        $this->setRedirect(Route::_('index.php?option=com_dictionary&view=letters', false), $msg);
    }

    /**
     * Method to check-in records.
     * 
     * @return void
     */
    public function checkin()
    {
        // Retrieve application and post data
        $app     = Factory::getApplication();
        $pks     = $app->input->post->get('cid', [], 'array');

        // Sanitize input
        ArrayHelper::toInteger($pks);

        // Validate selected records
        if (empty($pks)) {
            $app->enqueueMessage(Text::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'), 'error');
            return $this->setRedirect(Route::_('index.php?option=com_dictionary&view=letters', false));
        }

        // Build the WHERE clause
        $where = 'id IN (' . implode(',', $pks) . ')';

        // Execute check-in query
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->update($db->quoteName('#__dictionary_letters'))
            ->set('checked_out = 0')
            ->where($where);
        $db->setQuery($query);
        $db->execute();

        // Redirect after check-in
        $msg = Text::plural('COM_DICTIONARY_N_ITEMS_CHECKED_IN', count($pks));
        $this->setRedirect(Route::_('index.php?option=com_dictionary&view=letters', false), $msg);
    }
}
