<?php
/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net, updated by adedayo@jibitech.com
 **/

namespace Webeau\Component\Dictionary\Administrator\Controller;
// No direct access.
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Response\JsonResponse;
use Joomla\Input\Input;

/**
 * Letterdefinitions list controller class.
 */
class LetterdefinitionsController extends AdminController
{
    /**
	 * Constructor.
	 *
	 * @param   array                $config   An optional associative array of configuration settings.
	 * Recognized key values include 'name', 'default_task', 'model_path', and
	 * 'view_path' (this list is not meant to be comprehensive).
	 * @param   MVCFactoryInterface  $factory  The factory.
	 * @param   CMSApplication       $app      The Application for the dispatcher
	 * @param   Input                $input    Input
	 *
	 * @since   3.0
	 */
	public function __construct($config = array(), MVCFactoryInterface $factory = null, $app = null, $input = null)
	{
		parent::__construct($config, $factory, $app, $input);

	}


    /**
     * Proxy for getModel.
     * @since  1.6
     */
    public function getModel($name = 'Letterdefinition', $prefix = 'DictionaryModel', $config = ['ignore_request' => true])
    {
        return parent::getModel($name, $prefix, $config);
    }

    /**
     * Method to save the submitted ordering values for records via AJAX.
     *
     * @return  void
     *
     * @since   3.0
     */
    public function saveOrderAjax()
    {
        // Get the input
        $input = Factory::getApplication()->input;
        $pks = $input->post->get('cid', array(), 'array');
        $order = $input->post->get('order', array(), 'array');

        // Sanitize the input
        ArrayHelper::toInteger($pks);
        ArrayHelper::toInteger($order);

        // Get the model
        $model = $this->getModel();

        // Save the ordering
        $return = $model->saveorder($pks, $order);

        echo ($return) ? "1" : "0";

        // Close the application
        Factory::getApplication()->close();
    }

    public function publish($pks = null, $state = 1)
    {
        $redirectUrl = Route::_('index.php?option=com_dictionary&view=letterdefinitions', false);
        $pks = Factory::getApplication()->input->post->get('cid', array(), 'array');
        ArrayHelper::toInteger($pks);
        $state = (int) $state;

        $msg = (count($pks) > 1) 
            ? Text::sprintf('COM_DICTIONARY_N_ITEMS_PUBLISHED', count($pks)) 
            : Text::_('COM_DICTIONARY_N_ITEMS_PUBLISHED_1');

        if (Factory::getApplication()->input->post->get('task') === 'letterdefinitions.unpublish') {
            $state = 0;
            $msg = (count($pks) > 1) 
                ? Text::sprintf('COM_DICTIONARY_N_ITEMS_UNPUBLISHED', count($pks)) 
                : Text::_('COM_DICTIONARY_N_ITEMS_UNPUBLISHED_1');
        }

        if (empty($pks)) {
            $this->setRedirect($redirectUrl, Text::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
            return false;
        }

        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->update($db->quoteName('#__dictionary_letter_def'))
            ->set($db->quoteName('state') . ' = ' . (int) $state)
            ->where($db->quoteName('id') . ' IN (' . implode(',', $pks) . ')');
        $db->setQuery($query);
        $db->execute();

        $this->setRedirect($redirectUrl, $msg);
    }

    public function delete()
    {
        $redirectUrl = Route::_('index.php?option=com_dictionary&view=letterdefinitions', false);
        $pks = Factory::getApplication()->input->post->get('cid', array(), 'array');
        ArrayHelper::toInteger($pks);

        if (empty($pks)) {
            $this->setRedirect($redirectUrl, Text::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
            return false;
        }

        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->delete($db->quoteName('#__dictionary_letter_def'))
            ->where($db->quoteName('id') . ' IN (' . implode(',', $pks) . ')');
        $db->setQuery($query);
        $db->execute();

        $msg = (count($pks) > 1)
            ? Text::sprintf('COM_DICTIONARY_N_ITEMS_DELETED', count($pks))
            : Text::_('COM_DICTIONARY_N_ITEMS_DELETED_1');

        $this->setRedirect($redirectUrl, $msg);
    }

    public function checkin()
    {
        $redirectUrl = Route::_('index.php?option=com_dictionary&view=letterdefinitions', false);
        $pks = Factory::getApplication()->input->post->get('cid', array(), 'array');
        ArrayHelper::toInteger($pks);

        if (empty($pks)) {
            $this->setRedirect($redirectUrl, Text::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
            return false;
        }

        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->update($db->quoteName('#__dictionary_letter_def'))
            ->set($db->quoteName('checked_out') . ' = 0')
            ->where($db->quoteName('id') . ' IN (' . implode(',', $pks) . ')');
        $db->setQuery($query);
        $db->execute();

        $msg = (count($pks) > 1)
            ? Text::sprintf('COM_DICTIONARY_N_ITEMS_CHECKED_IN_1', count($pks))
            : Text::_('COM_DICTIONARY_N_ITEMS_CHECKED_IN_MORE');

        $this->setRedirect($redirectUrl, $msg);
    }
}
