<?php
/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015 - 2024. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net updated by adedayo@jibitech.com
 */

 namespace Webeau\Component\Dictionary\Administrator\Table;

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Table\Table;
use Joomla\CMS\Factory;
use Joomla\CMS\Access\Access;
use Joomla\Registry\Registry;
use Joomla\Utilities\ArrayHelper;

/**
 * Letter Table class
 */
class DictionaryTableLetter extends Table {

    /**
	 * Constructor
	 *
	 * @param   DatabaseDriver  $db  Database connector object
	 *
	 * @since   1.6
	 */
    public function __construct(DatabaseDriver $db) 
    {
        parent::__construct('#__dictionary_letters', 'id', $db);
    }

    //Extras from old code
    /**
     * Overloaded bind function to pre-process the params.
     *
     * @param	array		Named array
     * @param	string		Ignore field list
     * @return	bool|string	true on success, string on error
     */
    public function bind($array, $ignore = '') {

        if (isset($array['params']) && is_array($array['params'])) {
            $registry = new Registry();
            $registry->loadArray($array['params']);
            $array['params'] = (string) $registry;
        }

        if (isset($array['metadata']) && is_array($array['metadata'])) {
            $registry = new Registry();
            $registry->loadArray($array['metadata']);
            $array['metadata'] = (string) $registry;
        }

        // Handle ACL rules
        if (!Factory::getUser()->authorise('core.admin', 'com_dictionary.letter.' . $array['id'])) {
            $actions = Access::getActionsFromFile(JPATH_ADMINISTRATOR . '/components/com_dictionary/access.xml', "/access/section[@name='letter']/");
            $defaultActions = Access::getAssetRules('com_dictionary.letter.' . $array['id'])->getData();
            $arrayJaccess = [];
            foreach ($actions as $action) {
                $arrayJaccess[$action->name] = $defaultActions[$action->name];
            }
            $array['rules'] = $this->JAccessRulestoArray($arrayJaccess);
        }

        // Bind the rules for ACL where supported
        if (isset($array['rules']) && is_array($array['rules'])) {
            $this->setRules($array['rules']);
        }

        return parent::bind($array, $ignore);
    }

    /**
     * Converts an array of JAccessRule objects into a rules array.
     *
     * @param array $jaccessrules Array of JAccessRule objects.
     * @return array
     */
    private function JAccessRulestoArray($jaccessrules) {
        $rules = [];
        foreach ($jaccessrules as $action => $jaccess) {
            $actions = [];
            foreach ($jaccess->getData() as $group => $allow) {
                $actions[$group] = (bool) $allow;
            }
            $rules[$action] = $actions;
        }
        return $rules;
    }

    /**
     * Overloaded check function
     */
    public function check() {
        // If there is an ordering column and this is a new row, get the next ordering value
        if (property_exists($this, 'ordering') && $this->id == 0) {
            $this->ordering = self::getNextOrder();
        }

        return parent::check();
    }

    /**
     * Method to set the publishing state for a row or list of rows in the database table.
     *
     * @param	array|int|null	$pks    An optional array of primary key values to update. 
     * @param	int		        $state  The publishing state. eg. [0 = unpublished, 1 = published]
     * @param	int		        $userId The user id of the user performing the operation.
     * @return	bool            True on success.
     */
    public function publish($pks = null, $state = 1, $userId = 0) {
        $k = $this->_tbl_key;

        // Sanitize input.
        ArrayHelper::toInteger($pks);
        $userId = (int) $userId;
        $state = (int) $state;

        // If there are no primary keys set, check to see if the instance key is set.
        if (empty($pks)) {
            if ($this->$k) {
                $pks = [$this->$k];
            } else {
                $this->setError(JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
                return false;
            }
        }

        // Build the WHERE clause for the primary keys.
        $where = $k . '=' . implode(' OR ' . $k . '=', $pks);

        // Determine if there is check-in support for the table.
        $checkin = property_exists($this, 'checked_out') ? ' AND (checked_out = 0 OR checked_out = ' . (int) $userId . ')' : '';

        // Update the publishing state for rows with the given primary keys.
        $this->_db->setQuery(
            'UPDATE `' . $this->_tbl . '`' .
            ' SET `state` = ' . (int) $state .
            ' WHERE (' . $where . ')' .
            $checkin
        );
        $this->_db->execute();

        // Check for a database error.
        if ($this->_db->getErrorNum()) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }

        // Check in each row if supported and adjusted.
        if ($checkin && (count($pks) == $this->_db->getAffectedRows())) {
            foreach ($pks as $pk) {
                $this->checkin($pk);
            }
        }

        if (in_array($this->$k, $pks)) {
            $this->state = $state;
        }

        return true;
    }

    /**
     * Define a namespaced asset name for inclusion in the #__assets table
     * @return string The asset name
     */
    protected function _getAssetName() {
        return 'com_dictionary.letter.' . (int) $this->{$this->_tbl_key};
    }

    /**
     * Returns the parent asset's id. If there is a tree structure, retrieve the parent's id using the external key field.
     *
     * @param	Table|null	$table
     * @param	int|null	$id
     * @return	int
     */
    protected function _getAssetParentId(Table $table = null, $id = null) {
        $assetParent = Table::getInstance('Asset');
        $assetParentId = $assetParent->getRootId();
        $assetParent->loadByName('com_dictionary');
        return $assetParent->id ? $assetParent->id : $assetParentId;
    }

    public function delete($pk = null) {
        $this->load($pk);
        return parent::delete($pk);
    }
}
