<?php
/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015 - 2024. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net updated by adedayo@jibitech.com
 */

 namespace Webeau\Component\Dictionary\Administrator\Table;

 defined('JPATH_PLATFORM') or die;

 use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Access\Access;
use Joomla\CMS\Access\Rules;
use Joomla\Registry\Registry;
use Joomla\Utilities\ArrayHelper;

/**
 * Featured Table class.
 *
 * @since  1.6
 */
class LetterdefinitionsTable extends Table
{
    /**
	 * Constructor
	 *
	 * @param   DatabaseDriver  $db  Database connector object
	 *
	 * @since   1.6
	 */
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__dictionary_letter_def', 'id', $db);

		$this->setColumnAlias('published', 'state');
	}
    //Extras from old code
     /**
     * Bind function to pre-process the params.
     *
     * @param array $array Named array
     * @param string $ignore Space-separated list of fields to ignore
     * @return bool|null|string null if the operation was satisfactory, otherwise returns an error
     */
    public function bind(array $array, $ignore = ''): bool|string|null
    {
        if (isset($array['params']) && is_array($array['params'])) {
            $registry = new Registry();
            $registry->loadArray($array['params']);
            $array['params'] = (string) $registry;
        }

        if (isset($array['metadata']) && is_array($array['metadata'])) {
            $registry = new Registry();
            $registry->loadArray($array['metadata']);
            $array['metadata'] = (string) $registry;
        }

        if (!Factory::getUser()->authorise('core.admin', 'com_dictionary.letterdefinition.' . ($array['id'] ?? 0))) {
            $actions = Access::getActionsFromFile(
                JPATH_ADMINISTRATOR . '/components/com_dictionary/access.xml',
                "/access/section[@name='letterdefinition']/"
            );
            $defaultActions = Access::getAssetRules('com_dictionary.letterdefinition.' . ($array['id'] ?? 0))->getData();
            $arrayJAccess = [];

            foreach ($actions as $action) {
                $arrayJAccess[$action->name] = $defaultActions[$action->name];
            }
            $array['rules'] = $this->JAccessRulesToArray($arrayJAccess);
        }

        if (isset($array['rules']) && is_array($array['rules'])) {
            $this->setRules(new Rules($array['rules']));
        }

        return parent::bind($array, $ignore);
    }

    /**
     * Convert JAccessRule objects array to rules array.
     * @param array $jaccessRules Array of JAccessRule objects.
     * @return array
     */
    private function JAccessRulesToArray(array $jaccessRules): array
    {
        $rules = [];
        foreach ($jaccessRules as $action => $jaccess) {
            $actions = [];
            foreach ($jaccess->getData() as $group => $allow) {
                $actions[$group] = (bool) $allow;
            }
            $rules[$action] = $actions;
        }
        return $rules;
    }

    /**
     * Overloaded check function
     */
    public function check(): bool
    {
        if (property_exists($this, 'ordering') && $this->id == 0) {
            $this->ordering = self::getNextOrder();
        }
        return parent::check();
    }

    /**
     * Set the publishing state for a row or list of rows in the database.
     * @param array|int $pks Primary key values to update
     * @param int $state Publishing state
     * @param int $userId ID of the user performing the operation
     * @return bool True on success.
     */
    public function publish(array|int $pks = null, int $state = 1, int $userId = 0): bool
    {
        $k = $this->_tbl_key;

        $pks = (array) $pks;
        ArrayHelper::toInteger($pks);

        if (empty($pks)) {
            if ($this->$k) {
                $pks = [$this->$k];
            } else {
                $this->setError(Text::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
                return false;
            }
        }

        $where = $k . ' IN (' . implode(',', $pks) . ')';
        $checkin = (!property_exists($this, 'checked_out') || !property_exists($this, 'checked_out_time'))
            ? ''
            : ' AND (checked_out = 0 OR checked_out = ' . $userId . ')';

        $query = $this->_db->getQuery(true)
            ->update($this->_db->quoteName($this->_tbl))
            ->set('state = ' . $this->_db->quote($state))
            ->where($where . $checkin);

        $this->_db->setQuery($query);

        try {
            $this->_db->execute();
        } catch (\RuntimeException $e) {
            $this->setError($e->getMessage());
            return false;
        }

        if ($checkin && (count($pks) === $this->_db->getAffectedRows())) {
            foreach ($pks as $pk) {
                $this->checkin($pk);
            }
        }

        if (in_array($this->$k, $pks, true)) {
            $this->state = $state;
        }

        $this->setError('');
        return true;
    }

    /**
     * Define a namespaced asset name for inclusion in the #__assets table.
     * @return string The asset name.
     */
    protected function _getAssetName(): string
    {
        return 'com_dictionary.letterdefinition.' . (int) $this->{$this->_tbl_key};
    }

    /**
     * Returns the parent asset's id.
     * @return int
     */
    protected function _getAssetParentId(Table $table = null, $id = null): int
    {
        $assetParent = Table::getInstance('Asset');
        $assetParentId = $assetParent->getRootId();
        $assetParent->loadByName('com_dictionary');

        return $assetParent->id ? $assetParent->id : $assetParentId;
    }

    /**
     * Delete an entry by primary key
     * @param int|null $pk
     * @return bool
     */
    public function delete($pk = null): bool
    {
        $this->load($pk);
        return parent::delete($pk);
    }
}