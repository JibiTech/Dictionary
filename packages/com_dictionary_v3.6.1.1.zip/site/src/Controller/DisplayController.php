<?php

/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015 - 2024. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net updated by adedayo@jibitech.com
 */

 namespace Webeau\Component\Dictionary\Site\Controller;

 defined('JPATH_PLATFORM') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

 /**
 * Dictionary component controller
 *
 * @since  4.0.0
 */

 class DisplayController extends BaseController
 {
  protected $default_view = 'letters';
  protected $app;
 }