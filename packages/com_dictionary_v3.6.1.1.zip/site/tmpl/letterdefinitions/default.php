<?php
/**
 * @version     3.6.1.1
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015 - 2024. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net updated by adedayo@jibitech.com
 */

 defined('JPATH_PLATFORM') or die;
 
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\HTML\HTMLHelper;

// Get the document instance
$doc = Factory::getDocument();
$user = Factory::getUser();
$userId = $user->get('id');
$langd = Factory::getLanguage()->getTag();
$lang = '';

if (Multilanguage::isEnabled()) {
    $lang = !is_null($langd) && $langd != "*" ? " AND (language='" . Factory::getLanguage()->getTag() . "' OR language='*')" : "'*'";
}

$doc->addStyleSheet(JURI::base() . 'components/com_dictionary/assets/css/dictionary.css');
?>

<meta name="viewport" content="width=device-width, initial-scale=1" />

<?php
$app = Factory::getApplication();
$tview = $app->getParams()->get('show_template');

$db = Factory::getDbo();
$query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__dictionary_letters'))
            ->where($db->quoteName('state') . ' = 1')
            ->order($db->quoteName('letter_name'));
$db->setQuery($query);
$r1 = $db->loadObjectList();
?>

<?php if ($tview == '0') : ?>
    <style type="text/css">.collapse.in {display: block;}</style>
    <div class="atoz col-md-12">
        <div class='lexique'>
            <?php foreach ($r1 as $letter) : ?>
                <div class='set'>
                    <h3 class='letter'><?php echo $letter->letter_name; ?></h3>
                    <?php
                    $query->clear()
                          ->select('*')
                          ->from($db->quoteName('#__dictionary_letter_def'))
                          ->where($db->quoteName('letter_id') . " = " . $db->quote($letter->id))
                          ->where($db->quoteName('state') . ' = 1' . $lang)
                          ->order('word');
                    $db->setQuery($query);
                    $r2 = $db->loadObjectList();
                    ?>
                    <ul>
                        <?php $counter = 1; foreach ($r2 as $definition) : ?>
                            <div id='counter-<?php echo $counter; ?>' class='spoiler'>
                                <a data-toggle='collapse' data-target='#toggle-example-<?php echo $counter; ?>'>
                                    <?php echo $definition->word; ?>
                                </a>
                                <div id='toggle-example-<?php echo $counter; ?>' class='collapse'>
                                    <?php echo $definition->definition; ?>
                                </div>
                            </div>
                        <?php $counter++; endforeach; ?>
                    </ul>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <style>
        .atoz.col-md-12 {
            background: #fff;
            padding: 20px;
        }
    </style>

<?php else : ?>

    <div class="atoz col-md-12">
        <div class="glossary-items">
            <div id="t3-content" class="t3-content col-xs-12">
                <div class="glossary-nav">
                    <nav class="affix-top">
                        <ul class="nav nav-pills">
                            <?php foreach ($r1 as $letter) : ?>
                                <li><a href="#<?php echo strtolower($letter->letter_name); ?>"><?php echo $letter->letter_name; ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </nav>
                </div>
                <div class="glossary-items">
                    <div class="glossary-group">
                        <?php foreach ($r1 as $letter) : ?>
                            <a name="<?php echo strtolower($letter->letter_name); ?>"></a>
                            <h3 class="glossary-group-title"><?php echo $letter->letter_name; ?></h3>
                            <div class="glossary-group-items">
                                <ul class="row">
                                    <?php
                                    $query->clear()
                                          ->select('*')
                                          ->from($db->quoteName('#__dictionary_letter_def'))
                                          ->where($db->quoteName('state') . ' = 1')
                                          ->where($db->quoteName('letter_id') . " = " . $db->quote($letter->id) . $lang)
                                          ->order('word');
                                    $db->setQuery($query);
                                    $definitions = $db->loadObjectList();
                                    ?>
                                    <?php foreach ($definitions as $definition) : ?>
                                        <?php $string = preg_replace('/\s+/', '', $definition->word); ?>
                                        <li class="col-xs-12 col-sm-6 col-md-3">
                                            <a type="button" data-toggle="modal" data-target="#myModal<?php echo $string; ?>">
                                                <?php echo $definition->word; ?>
                                            </a>
                                            <!-- Modal -->
                                            <div id="myModal<?php echo $string; ?>" class="dmodel modal fade" role="dialog">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                            <h4 class="modal-title"><?php echo $definition->word; ?></h4>
                                                        </div>
                                                        <div class="modal-body">
                                                            <?php echo $definition->definition; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .atoz .glossary-group-title {
            margin: 0 0 24px;
            font-weight: 600;
            font-size: 35px;
            background: #f6f8f8;
            color: #344150;
            padding: 10px 15px;
            text-transform: uppercase;
        }
    </style>

<?php endif; ?>